"""Adds the Android 'Share to NEXORA' receiver after `npx cap add android`.
Safe to run more than once."""
import os
import re

ROOT = os.getcwd()
JAVA_DIR = os.path.join(ROOT, 'android/app/src/main/java/com/nexoora/app')
os.makedirs(JAVA_DIR, exist_ok=True)

MAIN = '''package com.nexoora.app;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import org.json.JSONObject;

public class MainActivity extends BridgeActivity {
    private static String pending = null;

    public static String takePending() {
        String p = pending;
        pending = null;
        return p;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NexoraSharePlugin.class);
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {
            capture(getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (capture(intent)) {
            final WebView wv = getBridge().getWebView();
            wv.post(new Runnable() {
                public void run() {
                    wv.evaluateJavascript("window.nexoraShareArrived && window.nexoraShareArrived()", null);
                }
            });
        }
    }

    private boolean capture(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return false;
        String type = intent.getType();
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (type == null || !type.startsWith("text/") || text == null) return false;
        try {
            JSONObject o = new JSONObject();
            o.put("text", text);
            String subject = intent.getStringExtra(Intent.EXTRA_SUBJECT);
            if (subject != null) o.put("subject", subject);
            pending = o.toString();
            intent.setAction(Intent.ACTION_MAIN);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
'''

PLUGIN = '''package com.nexoora.app;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "NexoraShare")
public class NexoraSharePlugin extends Plugin {
    @PluginMethod
    public void getPending(PluginCall call) {
        JSObject ret = new JSObject();
        String p = MainActivity.takePending();
        ret.put("value", p == null ? "" : p);
        call.resolve(ret);
    }
}
'''

with open(os.path.join(JAVA_DIR, 'MainActivity.java'), 'w') as f:
    f.write(MAIN)
with open(os.path.join(JAVA_DIR, 'NexoraSharePlugin.java'), 'w') as f:
    f.write(PLUGIN)

manifest = os.path.join(ROOT, 'android/app/src/main/AndroidManifest.xml')
s = open(manifest).read()
if 'android.intent.action.SEND' not in s:
    flt = '''            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="text/plain" />
            </intent-filter>
        '''
    if '</activity>' not in s:
        raise SystemExit('AndroidManifest.xml has no activity tag')
    s = s.replace('</activity>', flt + '</activity>', 1)
    open(manifest, 'w').write(s)
print('NEXORA share receiver added')

# Give every build a higher version number so Android treats it as a normal update
vc = os.environ.get('VERSION_CODE')
gradle = os.path.join(ROOT, 'android/app/build.gradle')
if vc and os.path.exists(gradle):
    g = open(gradle).read()
    g = re.sub(r'(versionCode\s*=?\s*)\d+', r'\g<1>' + vc, g)
    g = re.sub(r'(versionName\s*=?\s*)"[^"]*"', r'\g<1>"0.' + vc + '"', g)
    open(gradle, 'w').write(g)
    print('versionCode set to', vc)

# ---- Force the stable signing key (do not rely on ~/.android/debug.keystore being picked up) ----
if os.path.exists(gradle):
    g = open(gradle).read()
    if 'signingConfigs.nexora' not in g:
        keystore = os.path.join(ROOT, 'nexora-debug.keystore').replace('\\', '/')
        block = (
            '\n    signingConfigs {\n'
            '        nexora {\n'
            '            storeFile file("%s")\n'
            '            storePassword "android"\n'
            '            keyAlias "androiddebugkey"\n'
            '            keyPassword "android"\n'
            '        }\n'
            '    }\n' % keystore)
        g, n1 = re.subn(r'(^android\s*\{)', lambda m: m.group(1) + block, g, count=1, flags=re.M)
        g, n2 = re.subn(r'(buildTypes\s*\{)', lambda m: m.group(1) + '\n        debug {\n            signingConfig signingConfigs.nexora\n        }', g, count=1)
        if not (n1 and n2):
            raise SystemExit('Could not add signing config to build.gradle')
        open(gradle, 'w').write(g)
        print('stable signing key configured')
