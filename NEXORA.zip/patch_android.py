"""Adds the Android 'Share to NEXORA' receiver after `npx cap add android`.
Safe to run more than once."""
import os
import re

ROOT = os.getcwd()
JAVA_DIR = os.path.join(ROOT, 'android/app/src/main/java/com/nexoora/app')
os.makedirs(JAVA_DIR, exist_ok=True)

MAIN = '''package com.nexoora.app;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends BridgeActivity {
    private static volatile String pending = null;

    public static synchronized String takePending() {
        String p = pending;
        pending = null;
        return p;
    }

    private static synchronized void setPending(String p) {
        pending = p;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NexoraSharePlugin.class);
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {
            capture(getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        capture(intent);
    }

    private void notifyWeb() {
        try {
            final WebView wv = getBridge().getWebView();
            wv.post(new Runnable() {
                public void run() {
                    wv.evaluateJavascript("window.nexoraShareArrived && window.nexoraShareArrived()", null);
                }
            });
        } catch (Exception e) {
            // page not ready yet; the page asks for pending shares when it starts
        }
    }

    private void capture(final Intent intent) {
        if (intent == null) return;
        final String action = intent.getAction();
        if (!Intent.ACTION_SEND.equals(action) && !Intent.ACTION_SEND_MULTIPLE.equals(action)) return;
        intent.setAction(Intent.ACTION_MAIN);
        final String type = intent.getType();
        final String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        final String subject = intent.getStringExtra(Intent.EXTRA_SUBJECT);
        final ArrayList<Uri> uris = new ArrayList<Uri>();
        if (Intent.ACTION_SEND.equals(action)) {
            Uri u = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) uris.add(u);
        } else {
            ArrayList<Uri> many = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (many != null) uris.addAll(many);
        }
        if (uris.isEmpty() && text == null) return;
        new Thread(new Runnable() {
            public void run() {
                try {
                    JSONObject o = new JSONObject();
                    if (text != null) o.put("text", text);
                    if (subject != null) o.put("subject", subject);
                    if (type != null) o.put("mime", type);
                    JSONArray files = new JSONArray();
                    for (Uri u : uris) {
                        try {
                            files.put(copyStream(u));
                        } catch (Exception e) {
                            // skip a file that cannot be read
                        }
                    }
                    if (files.length() > 0) o.put("files", files);
                    if (files.length() == 0 && text == null) return;
                    setPending(o.toString());
                    notifyWeb();
                } catch (Exception e) {
                    // ignore
                }
            }
        }).start();
    }

    private JSONObject copyStream(Uri uri) throws Exception {
        ContentResolver cr = getContentResolver();
        String name = "file";
        Cursor c = cr.query(uri, null, null, null, null);
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (ni >= 0 && c.getString(ni) != null) name = c.getString(ni);
                }
            } finally {
                c.close();
            }
        }
        String mime = cr.getType(uri);
        if (mime == null) mime = "application/octet-stream";
        File dir = new File(getCacheDir(), "nexora_in");
        dir.mkdirs();
        File out = new File(dir, System.currentTimeMillis() + "_" + name.replaceAll("[^A-Za-z0-9._ -]", "_"));
        InputStream in = cr.openInputStream(uri);
        OutputStream os = new FileOutputStream(out);
        byte[] buf = new byte[65536];
        int n;
        long total = 0;
        while ((n = in.read(buf)) > 0) {
            os.write(buf, 0, n);
            total += n;
        }
        in.close();
        os.close();
        JSONObject o = new JSONObject();
        o.put("path", out.getAbsolutePath());
        o.put("name", name);
        o.put("mime", mime);
        o.put("size", total);
        return o;
    }
}
'''

PLUGIN = '''package com.nexoora.app;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "NexoraShare")
public class NexoraSharePlugin extends Plugin {
    @PluginMethod
    public void getPending(PluginCall call) {
        JSObject ret = new JSObject();
        String p = MainActivity.takePending();
        ret.put("value", p == null ? "" : p);
        call.resolve(ret);
    }
}
'''

with open(os.path.join(JAVA_DIR, 'MainActivity.java'), 'w') as f:
    f.write(MAIN)
with open(os.path.join(JAVA_DIR, 'NexoraSharePlugin.java'), 'w') as f:
    f.write(PLUGIN)

manifest = os.path.join(ROOT, 'android/app/src/main/AndroidManifest.xml')
s = open(manifest).read()
if 'SEND_MULTIPLE' not in s:
    flt = '''            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="*/*" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.SEND_MULTIPLE" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="*/*" />
            </intent-filter>
        '''
    if 'android.intent.action.SEND"' in s:
        s = s.replace('<data android:mimeType="text/plain" />', '<data android:mimeType="text/plain" />', 1)
    if '</activity>' not in s:
        raise SystemExit('AndroidManifest.xml has no activity tag')
    s = s.replace('</activity>', flt + '</activity>', 1)
    open(manifest, 'w').write(s)
print('NEXORA share receiver added')

# Give every build a higher version number so Android treats it as a normal update
vc = os.environ.get('VERSION_CODE')
gradle = os.path.join(ROOT, 'android/app/build.gradle')
if vc and os.path.exists(gradle):
    g = open(gradle).read()
    g = re.sub(r'(versionCode\s*=?\s*)\d+', r'\g<1>' + vc, g)
    g = re.sub(r'(versionName\s*=?\s*)"[^"]*"', r'\g<1>"0.' + vc + '"', g)
    open(gradle, 'w').write(g)
    print('versionCode set to', vc)

# ---- Force the stable signing key (do not rely on ~/.android/debug.keystore being picked up) ----
if os.path.exists(gradle):
    g = open(gradle).read()
    if 'signingConfigs.nexora' not in g:
        keystore = os.path.join(ROOT, 'nexora-debug.keystore').replace('\\', '/')
        block = (
            '\n    signingConfigs {\n'
            '        nexora {\n'
            '            storeFile file("%s")\n'
            '            storePassword "android"\n'
            '            keyAlias "androiddebugkey"\n'
            '            keyPassword "android"\n'
            '        }\n'
            '    }\n' % keystore)
        g, n1 = re.subn(r'(^android\s*\{)', lambda m: m.group(1) + block, g, count=1, flags=re.M)
        g, n2 = re.subn(r'(buildTypes\s*\{)', lambda m: m.group(1) + '\n        debug {\n            signingConfig signingConfigs.nexora\n        }', g, count=1)
        if not (n1 and n2):
            raise SystemExit('Could not add signing config to build.gradle')
        open(gradle, 'w').write(g)
        print('stable signing key configured')

# ---- Permanent app id (the app you installed from NEXORA-new-install.apk) ----
if os.path.exists(gradle):
    g = open(gradle).read()
    g2, n = re.subn(r'(applicationId\s*=?\s*)"com\.nexoora\.app"', r'\g<1>"com.nexoora.library"', g)
    if n:
        open(gradle, 'w').write(g2)
        print('applicationId set to com.nexoora.library')
