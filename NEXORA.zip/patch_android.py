"""Adds the Android 'Share to NEXORA' receiver after `npx cap add android`.
Safe to run more than once."""
import os

ROOT = os.getcwd()
JAVA_DIR = os.path.join(ROOT, 'android/app/src/main/java/com/nexoora/app')
os.makedirs(JAVA_DIR, exist_ok=True)

MAIN = '''package com.nexoora.app;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import org.json.JSONObject;

public class MainActivity extends BridgeActivity {
    private static String pending = null;

    public static String takePending() {
        String p = pending;
        pending = null;
        return p;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NexoraSharePlugin.class);
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {
            capture(getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (capture(intent)) {
            final WebView wv = getBridge().getWebView();
            wv.post(new Runnable() {
                public void run() {
                    wv.evaluateJavascript("window.nexoraShareArrived && window.nexoraShareArrived()", null);
                }
            });
        }
    }

    private boolean capture(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return false;
        String type = intent.getType();
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (type == null || !type.startsWith("text/") || text == null) return false;
        try {
            JSONObject o = new JSONObject();
            o.put("text", text);
            String subject = intent.getStringExtra(Intent.EXTRA_SUBJECT);
            if (subject != null) o.put("subject", subject);
            pending = o.toString();
            intent.setAction(Intent.ACTION_MAIN);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
'''

PLUGIN = '''package com.nexoora.app;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "NexoraShare")
public class NexoraSharePlugin extends Plugin {
    @PluginMethod
    public void getPending(PluginCall call) {
        JSObject ret = new JSObject();
        String p = MainActivity.takePending();
        ret.put("value", p == null ? "" : p);
        call.resolve(ret);
    }
}
'''

with open(os.path.join(JAVA_DIR, 'MainActivity.java'), 'w') as f:
    f.write(MAIN)
with open(os.path.join(JAVA_DIR, 'NexoraSharePlugin.java'), 'w') as f:
    f.write(PLUGIN)

manifest = os.path.join(ROOT, 'android/app/src/main/AndroidManifest.xml')
s = open(manifest).read()
if 'android.intent.action.SEND' not in s:
    flt = '''            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="text/plain" />
            </intent-filter>
        '''
    if '</activity>' not in s:
        raise SystemExit('AndroidManifest.xml has no activity tag')
    s = s.replace('</activity>', flt + '</activity>', 1)
    open(manifest, 'w').write(s)
print('NEXORA share receiver added')
