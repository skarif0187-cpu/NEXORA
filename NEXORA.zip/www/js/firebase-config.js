// NEXORA Firebase web config (used from step 5: login and sync).
// If login ever says "api-key-not-valid", re-copy apiKey from Firebase Console.
window.NEXORA_FIREBASE = {
  apiKey: "AIzaSyAbOLNEFXTKxLFCCUSrMZCOE6fDThjWUOU",
  authDomain: "nexora-600d6.firebaseapp.com",
  projectId: "nexora-600d6",
  storageBucket: "nexora-600d6.firebasestorage.app",
  messagingSenderId: "510185176593",
  appId: "1:510185176593:web:78a2fbbc5389be23743bb0"
};
