/* NEXORA local database (IndexedDB) with an in-memory copy for instant screens.
   Stores: collections, items, links (item <-> collection), platforms.
   Every record has createdAt/updatedAt/deletedAt so cloud sync can be added later. */
var NexoraDB = (function () {
  'use strict';
  var NAME = 'nexora', VERSION = 2;
  var STORES = ['collections', 'items', 'links', 'platforms', 'rules'];
  var db = null;
  var listener = null;
  var mem = { collections: [], items: [], links: [], platforms: [], rules: [] };

  function indexOf(arr, id) {
    for (var i = 0; i < arr.length; i++) if (arr[i].id === id) return i;
    return -1;
  }

  function loadAll() {
    return Promise.all(STORES.map(function (s) {
      return new Promise(function (resolve) {
        var rq = db.transaction(s).objectStore(s).getAll();
        rq.onsuccess = function () { mem[s] = rq.result || []; resolve(); };
        rq.onerror = function () { resolve(); };
      });
    }));
  }

  function open() {
    return new Promise(function (resolve) {
      if (!window.indexedDB) { resolve(); return; }
      var rq;
      try { rq = indexedDB.open(NAME, VERSION); } catch (e) { resolve(); return; }
      rq.onupgradeneeded = function () {
        var d = rq.result;
        STORES.forEach(function (s) {
          if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: 'id' });
        });
      };
      rq.onsuccess = function () { db = rq.result; loadAll().then(resolve); };
      rq.onerror = function () { resolve(); };
    });
  }

  function put(store, obj, silent) {
    var i = indexOf(mem[store], obj.id);
    if (i < 0) mem[store].push(obj); else mem[store][i] = obj;
    if (!silent && listener) listener(store, obj.id);
    if (!db) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).put(obj);
      tx.oncomplete = function () { resolve(); };
      tx.onerror = function () { reject(tx.error); };
    });
  }

  function remove(store, id, silent) {
    var i = indexOf(mem[store], id);
    if (i >= 0) mem[store].splice(i, 1);
    if (!silent && listener) listener(store, id);
    if (!db) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).delete(id);
      tx.oncomplete = function () { resolve(); };
      tx.onerror = function () { reject(tx.error); };
    });
  }

  return {
    open: open,
    put: put,
    remove: remove,
    all: function (s) { return mem[s]; },
    get: function (s, id) { var i = indexOf(mem[s], id); return i < 0 ? null : mem[s][i]; },
    setListener: function (fn) { listener = fn; },
    persistent: function () { return !!db; }
  };
})();
