/* NEXORA account + cloud backup.
   Uses Firebase's REST interface directly (no extra libraries, works from the app's web view).
   Every record has updatedAt; the newest copy wins; deletions are stored as small tombstones,
   so nothing is silently lost. Files are not backed up yet (links, notes, folders, settings of
   collections and rules are). */
var NexoraSync = (function () {
  'use strict';
  var cfg = window.NEXORA_FIREBASE || {};
  var KEY = cfg.apiKey, PID = cfg.projectId;
  var BASE = 'https://firestore.googleapis.com/v1/projects/' + PID + '/databases/(default)/documents';
  var NAME = 'projects/' + PID + '/databases/(default)/documents';
  var STORES = ['collections', 'items', 'links', 'platforms', 'rules'];
  var DB = NexoraDB;

  function lget(k, d) { try { var v = localStorage.getItem('nexora.sync.' + k); return v === null ? d : v; } catch (e) { return d; } }
  function lset(k, v) { try { localStorage.setItem('nexora.sync.' + k, v); } catch (e) { /* ignore */ } }
  function ljson(k, d) { try { return JSON.parse(lget(k, '')) || d; } catch (e) { return d; } }

  var session = ljson('session', null);
  var dirty = ljson('dirty', {});
  var st = { busy: false, error: '', lastSync: Number(lget('last', '0')) || 0 };
  var onRemote = function () {};
  var onStatus = function () {};
  var timer = null;

  function saveDirty() { lset('dirty', JSON.stringify(dirty)); }
  function ts(o) { return (o && (o.updatedAt || o.addedAt || o.createdAt)) || 0; }
  function status() { onStatus(); }

  function friendly(msg) {
    msg = String(msg || '');
    if (/EMAIL_EXISTS/.test(msg)) return 'This email already has an account. Try Sign in.';
    if (/INVALID_LOGIN_CREDENTIALS|INVALID_PASSWORD|EMAIL_NOT_FOUND/.test(msg)) return 'Wrong email or password.';
    if (/WEAK_PASSWORD/.test(msg)) return 'Password must be at least 6 characters.';
    if (/INVALID_EMAIL|MISSING_EMAIL/.test(msg)) return 'Enter a valid email address.';
    if (/MISSING_PASSWORD/.test(msg)) return 'Enter your password.';
    if (/TOO_MANY_ATTEMPTS/.test(msg)) return 'Too many tries. Wait a few minutes and try again.';
    if (/API key/i.test(msg)) return 'The app key is not accepted. Tell your developer: API key problem.';
    if (/OPERATION_NOT_ALLOWED/.test(msg)) return 'Email sign-in is not turned on in Firebase.';
    if (/PERMISSION_DENIED|Missing or insufficient/i.test(msg)) return 'Cloud rules are not published yet. Publish the Firestore rules.';
    if (/Failed to fetch|NetworkError|Load failed|network/i.test(msg)) return 'No internet connection.';
    return msg || 'Something went wrong.';
  }

  function post(url, body, form) {
    var opts = { method: 'POST', headers: { 'Content-Type': form ? 'application/x-www-form-urlencoded' : 'application/json' }, body: form ? body : JSON.stringify(body) };
    return fetch(url, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { throw new Error(friendly((j.error && (j.error.message || j.error)) || 'HTTP ' + r.status)); }
        return j;
      });
    }, function (e) { throw new Error(friendly(e && e.message)); });
  }

  function setSession(j, email) {
    session = {
      uid: j.localId || j.user_id || (session && session.uid),
      email: email || (session && session.email) || '',
      idToken: j.idToken || j.id_token,
      refreshToken: j.refreshToken || j.refresh_token,
      expiresAt: Date.now() + (Number(j.expiresIn || j.expires_in) || 3600) * 1000
    };
    lset('session', JSON.stringify(session));
  }

  function token() {
    if (!session) return Promise.reject(new Error('Not signed in.'));
    if (Date.now() < session.expiresAt - 60000) return Promise.resolve(session.idToken);
    return post('https://securetoken.googleapis.com/v1/token?key=' + KEY,
      'grant_type=refresh_token&refresh_token=' + encodeURIComponent(session.refreshToken), true)
      .then(function (j) { setSession(j); return session.idToken; });
  }

  function authed(url, opts) {
    return token().then(function (t) {
      opts = opts || {};
      opts.headers = { 'Authorization': 'Bearer ' + t, 'Content-Type': 'application/json' };
      return fetch(url, opts);
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { throw new Error(friendly((j.error && j.error.message) || 'HTTP ' + r.status)); }
        return j;
      });
    }, function (e) { throw new Error(friendly(e && e.message)); });
  }

  /* ---- account ---- */
  function markAllDirty() {
    STORES.forEach(function (s) { DB.all(s).forEach(function (o) { dirty[s + '|' + o.id] = 1; }); });
    saveDirty();
  }
  function enter(j, email) {
    setSession(j, email);
    markAllDirty();
    status();
    return syncNow();
  }
  function signUp(email, pw) {
    return post('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=' + KEY, { email: email, password: pw, returnSecureToken: true })
      .then(function (j) { return enter(j, email); });
  }
  function signIn(email, pw) {
    return post('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' + KEY, { email: email, password: pw, returnSecureToken: true })
      .then(function (j) { return enter(j, email); });
  }
  function reset(email) {
    return post('https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=' + KEY, { requestType: 'PASSWORD_RESET', email: email });
  }
  function signOut() {
    session = null; lset('session', ''); lset('last', '0'); st.lastSync = 0; st.error = '';
    clearTimeout(timer);
    status();
  }

  /* ---- records <-> cloud documents ---- */
  function docId(store, id) { return store + '~' + id; }
  function toWrite(store, id) {
    var obj = DB.get(store, id), t = obj ? ts(obj) : Date.now();
    var fields = {
      store: { stringValue: store }, rid: { stringValue: id },
      updatedAt: { integerValue: String(t) }, tomb: { booleanValue: !obj }
    };
    if (obj) fields.json = { stringValue: JSON.stringify(obj) };
    return { update: { name: NAME + '/users/' + session.uid + '/records/' + docId(store, id), fields: fields } };
  }

  function push() {
    var keys = Object.keys(dirty);
    if (!keys.length) return Promise.resolve(0);
    var chunks = [];
    for (var i = 0; i < keys.length; i += 100) chunks.push(keys.slice(i, i + 100));
    var done = 0;
    return chunks.reduce(function (p, chunk) {
      return p.then(function () {
        var writes = chunk.map(function (k) { var a = k.split('|'); return toWrite(a[0], a.slice(1).join('|')); });
        return authed(BASE.replace('/documents', '') + '/documents:commit', { method: 'POST', body: JSON.stringify({ writes: writes }) })
          .then(function () { chunk.forEach(function (k) { delete dirty[k]; }); saveDirty(); done += chunk.length; });
      });
    }, Promise.resolve()).then(function () { return done; });
  }

  function field(f, name, kind) { return f && f[name] ? f[name][kind] : undefined; }

  function pull() {
    var changed = 0;
    function page(token2) {
      var url = BASE + '/users/' + session.uid + '/records?pageSize=300' + (token2 ? '&pageToken=' + encodeURIComponent(token2) : '');
      return authed(url, { method: 'GET' }).then(function (j) {
        (j.documents || []).forEach(function (d) {
          var f = d.fields || {}, store = field(f, 'store', 'stringValue'), rid = field(f, 'rid', 'stringValue');
          if (STORES.indexOf(store) < 0 || !rid) return;
          var t = Number(field(f, 'updatedAt', 'integerValue')) || 0, local = DB.get(store, rid);
          if (!local && dirty[store + '|' + rid]) return; // deleted here, waiting to upload the deletion
          if (field(f, 'tomb', 'booleanValue')) {
            if (local && ts(local) <= t) { DB.remove(store, rid, true); changed++; }
          } else if (!local || t > ts(local)) {
            try { DB.put(store, JSON.parse(field(f, 'json', 'stringValue')), true); changed++; } catch (e) { /* skip bad record */ }
          }
        });
        return j.nextPageToken ? page(j.nextPageToken) : changed;
      });
    }
    return page('');
  }

  function syncNow() {
    if (!session) return Promise.resolve(null);
    if (st.busy) return Promise.resolve(null);
    st.busy = true; st.error = ''; status();
    return pull().then(function (n) {
      return push().then(function (pushed) { return { pulled: n, pushed: pushed }; });
    }).then(function (r) {
      st.lastSync = Date.now(); lset('last', String(st.lastSync));
      st.busy = false; status();
      if (r.pulled) onRemote();
      return r;
    }).catch(function (e) {
      st.busy = false; st.error = e.message || 'Sync failed'; status();
      throw e;
    });
  }

  function schedule() {
    if (!session) return;
    clearTimeout(timer);
    timer = setTimeout(function () { syncNow().catch(function () { /* shown in status */ }); }, 3000);
  }

  function start(handlers) {
    onRemote = handlers.onRemote || onRemote;
    onStatus = handlers.onStatus || onStatus;
    DB.setListener(function (store, id) {
      if (STORES.indexOf(store) < 0) return;
      dirty[store + '|' + id] = 1; saveDirty(); schedule();
    });
    if (session) syncNow().catch(function () { /* shown in status */ });
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden && session && Date.now() - st.lastSync > 60000) syncNow().catch(function () { /* ignore */ });
    });
  }

  return {
    start: start, signUp: signUp, signIn: signIn, signOut: signOut, reset: reset, syncNow: syncNow,
    signedIn: function () { return !!session; },
    email: function () { return session ? session.email : ''; },
    state: function () { return { busy: st.busy, error: st.error, lastSync: st.lastSync, pending: Object.keys(dirty).length }; }
  };
})();
