/* NEXORA - step 2: collections, items, trash, search, themes */
(function () {
  'use strict';

  var VERSION = '0.2 (step 2)';
  var DAY = 86400000;
  var DB = NexoraDB;

  var ICONS = {
    home: '<path d="M4 11l8-6.5L20 11v8a1 1 0 0 1-1 1h-4v-5h-6v5H5a1 1 0 0 1-1-1z"/>',
    grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.8"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    bookmark: '<path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z"/>',
    sliders: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/>',
    folder: '<path d="M3.5 7.5A1.5 1.5 0 0 1 5 6h4l2 2.2h8a1.5 1.5 0 0 1 1.5 1.5v8.3a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 18z"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    image: '<rect x="4" y="5" width="16" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M5 17l4.5-4.5 3.5 3.5 2.5-2.5L20 16"/>',
    file: '<path d="M7 3.5h6.5L18 8v11.5a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-15a1 1 0 0 1 1-1z"/><path d="M13.5 3.5V8H18"/>',
    video: '<rect x="4" y="6" width="16" height="12" rx="3"/><path d="M10.5 9.5v5l4-2.5z"/>',
    note: '<path d="M6 4.5h12a1 1 0 0 1 1 1V16l-4 4H6a1 1 0 0 1-1-1V5.5a1 1 0 0 1 1-1z"/><path d="M8.5 9h7M8.5 12.5h5"/>',
    upload: '<path d="M12 16V5M7.5 9.5L12 5l4.5 4.5"/><path d="M5 15v3a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3"/>',
    chev: '<path d="M9.5 6l6 6-6 6"/>',
    back: '<path d="M14.5 6l-6 6 6 6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    user: '<circle cx="12" cy="8.5" r="3.5"/><path d="M5 19.5c.8-3.6 3.6-5.5 7-5.5s6.2 1.9 7 5.5"/>',
    palette: '<path d="M12 4a8 8 0 1 0 0 16c1.2 0 1.8-.8 1.8-1.6 0-1.3-1-1.4-1-2.6 0-.9.7-1.5 1.6-1.5H16a4 4 0 0 0 4-4C20 6.9 16.4 4 12 4z"/><circle cx="8.5" cy="11" r="1"/><circle cx="12" cy="8" r="1"/><circle cx="15.5" cy="10" r="1"/>',
    lock: '<rect x="5" y="10.5" width="14" height="9.5" rx="2.5"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
    cloud: '<path d="M7.5 18.5a4 4 0 0 1-.6-7.95A5.5 5.5 0 0 1 17.5 9.5a4.5 4.5 0 0 1-.5 9z"/>',
    archive: '<rect x="4" y="5" width="16" height="4.5" rx="1.5"/><path d="M5.5 9.5V18a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V9.5M10 13h4"/>',
    storage: '<ellipse cx="12" cy="6.5" rx="7" ry="2.8"/><path d="M5 6.5v11c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8v-11"/><path d="M5 12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8"/>',
    route: '<path d="M4 7h4l8 10h4M4 17h4l2.5-3.2M13.5 10.2L16 7h4"/><path d="M18 5l2 2-2 2M18 15l2 2-2 2"/>',
    phone: '<rect x="7" y="3.5" width="10" height="17" rx="2.5"/><path d="M11 17.5h2"/>',
    exportIc: '<path d="M12 4v11M7.5 10.5L12 15l4.5-4.5"/><path d="M5 17v1.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V17"/>',
    info: '<circle cx="12" cy="12" r="8"/><path d="M12 11v5M12 8v.1"/>',
    star: '<path d="M12 4.5l2.2 4.6 5 .7-3.6 3.5.9 5-4.5-2.4-4.5 2.4.9-5L4.8 9.8l5-.7z"/>',
    list: '<path d="M5 7h14M5 12h14M5 17h14"/>',
    mixed: '<rect x="4" y="4" width="16" height="7" rx="1.8"/><rect x="4" y="14" width="7" height="6" rx="1.8"/><rect x="14" y="14" width="6" height="6" rx="1.8"/>',
    trash: '<path d="M5 7h14M10 7V5h4v2M7 7l.8 12a1 1 0 0 0 1 .9h6.4a1 1 0 0 0 1-.9L17 7"/>',
    clock: '<circle cx="12" cy="12" r="8"/><path d="M12 8v4.5l3 1.5"/>',
    edit: '<path d="M5 19l1-4L16 5l3 3L9 18z"/>',
    external: '<path d="M14 5h5v5M19 5l-8 8M18 14v4a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h4"/>'
  };
  var FOLDER_ICONS = ['folder', 'star', 'bookmark', 'note', 'video', 'image', 'lock', 'cloud'];
  var COLORS = [
    { name: 'Jade', c: '62,160,120' }, { name: 'Gold', c: '212,168,60' },
    { name: 'Clay', c: '196,120,96' }, { name: 'Steel', c: '110,140,190' },
    { name: 'Rose', c: '196,76,108' }, { name: 'Plum', c: '150,120,170' },
    { name: 'Sage', c: '130,160,140' }, { name: 'Copper', c: '210,118,74' }
  ];
  var PALETTES = [
    { id: 'emerald', name: 'Emerald and Champagne', dots: ['#0D2119', '#F4EBD6', '#D8B455'] },
    { id: 'burgundy', name: 'Burgundy and Bronze', dots: ['#220D16', '#F3E6CF', '#D08A45'] },
    { id: 'midnight', name: 'Midnight and Brass', dots: ['#141B2B', '#EFE7D3', '#C9996B'] },
    { id: 'espresso', name: 'Espresso and Copper', dots: ['#1E1613', '#F2E6DA', '#D2764A'] },
    { id: 'nexora', name: 'Nexora Blue', dots: ['#0B1530', '#EAF2FF', '#1F6BFF'] }
  ];
  var SEED_PLATFORMS = [
    { id: 'youtube', name: 'YouTube', color: '255,59,48', domains: ['youtube.com', 'youtu.be'] },
    { id: 'facebook', name: 'Facebook', color: '24,119,242', domains: ['facebook.com', 'fb.watch', 'fb.com'] },
    { id: 'tiktok', name: 'TikTok', color: '20,190,200', domains: ['tiktok.com'] },
    { id: 'whatsapp', name: 'WhatsApp', color: '37,190,95', domains: ['whatsapp.com', 'wa.me'] },
    { id: 'instagram', name: 'Instagram', color: '225,48,108', domains: ['instagram.com'] },
    { id: 'web', name: 'Websites', color: '110,140,190', domains: [] },
    { id: 'docs', name: 'Documents', color: '212,168,60', domains: [] }
  ];

  function ic(name) {
    return '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || ICONS.folder) + '</svg>';
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function el(id) { return document.getElementById(id); }
  function uid() {
    try { if (window.crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) { /* fall through */ }
    return 'id' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }
  function now() { return Date.now(); }
  function fmtDate(ts) {
    try { return new Date(ts).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }); } catch (e) { return ''; }
  }
  function daysLeft(ts) { return Math.max(0, 30 - Math.floor((now() - ts) / DAY)); }

  /* ---------- storage + theme ---------- */
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('nexora.' + k); return v === null ? d : v; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('nexora.' + k, v); } catch (e) { /* ignore */ } }
  };
  var state = {
    theme: store.get('theme', 'system'),
    palette: store.get('palette', 'emerald'),
    rotate: store.get('rotate', '1') === '1',
    filter: 'all',
    view: store.get('view', 'mixed')
  };
  if (state.rotate) {
    var lastP = store.get('last', '');
    var pool = PALETTES.filter(function (p) { return p.id !== lastP; });
    var chosen = pool[Math.floor(Math.random() * pool.length)];
    state.palette = chosen.id;
    store.set('last', chosen.id);
  }
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function applyTheme() {
    var dark = mq ? mq.matches : true;
    var mode = state.theme === 'system' ? (dark ? 'dark' : 'light') : state.theme;
    var root = document.documentElement;
    root.setAttribute('data-mode', mode);
    root.setAttribute('data-palette', state.palette);
    var meta = document.querySelector('meta[name="theme-color"]');
    var bg = getComputedStyle(root).getPropertyValue('--bg').trim();
    if (meta && bg) meta.setAttribute('content', bg);
  }
  if (mq) {
    if (mq.addEventListener) mq.addEventListener('change', applyTheme);
    else if (mq.addListener) mq.addListener(applyTheme);
  }
  applyTheme();

  /* ---------- data helpers ---------- */
  function liveCols() { return DB.all('collections').filter(function (c) { return !c.deletedAt; }); }
  function byOrder(a, b) { return (a.order || 0) - (b.order || 0) || a.createdAt - b.createdAt; }
  function children(pid) { return liveCols().filter(function (c) { return (c.parentId || null) === (pid || null); }).sort(byOrder); }
  function collection(id) { var c = DB.get('collections', id); return c && !c.deletedAt ? c : null; }
  function descendantIds(id) {
    var out = [];
    DB.all('collections').forEach(function (c) { if (c.parentId === id && !c.deletedAt) { out.push(c.id); out = out.concat(descendantIds(c.id)); } });
    return out;
  }
  function pathOf(id) {
    var names = [], c = DB.get('collections', id), guard = 0;
    while (c && guard++ < 20) { names.unshift(c.name); c = c.parentId ? DB.get('collections', c.parentId) : null; }
    return names.join(' / ');
  }
  function liveItems() { return DB.all('items').filter(function (i) { return !i.deletedAt; }); }
  function itemsIn(cid) {
    var ids = {};
    DB.all('links').forEach(function (l) { if (l.collectionId === cid) ids[l.itemId] = 1; });
    return liveItems().filter(function (i) { return ids[i.id] && !i.archived; }).sort(function (a, b) { return b.createdAt - a.createdAt; });
  }
  function collectionsOf(itemId) {
    var out = [];
    DB.all('links').forEach(function (l) { if (l.itemId === itemId) { var c = collection(l.collectionId); if (c) out.push(c); } });
    return out;
  }
  function platform(id) { return DB.get('platforms', id); }
  function platformFor(url) {
    var host = '';
    try { host = new URL(url).hostname.replace(/^www\./, '').toLowerCase(); } catch (e) { return 'web'; }
    var list = DB.all('platforms');
    for (var i = 0; i < list.length; i++) {
      var d = list[i].domains || [];
      for (var j = 0; j < d.length; j++) {
        var dom = String(d[j]).toLowerCase();
        if (host === dom || host.slice(-(dom.length + 1)) === '.' + dom) return list[i].id;
      }
    }
    return 'web';
  }
  function normalizeUrl(input) {
    var s = String(input || '').trim();
    if (!s) return null;
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = 'https://' + s;
    try {
      var u = new URL(s);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
      if (u.hostname.indexOf('.') < 0) return null;
      return u.href;
    } catch (e) { return null; }
  }
  function domainOf(url) { try { return new URL(url).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }
  function parseTags(s) {
    var seen = {}, out = [];
    String(s || '').split(/[,\n]/).forEach(function (t) {
      t = t.trim().replace(/^#/, '');
      if (t && !seen[t.toLowerCase()]) { seen[t.toLowerCase()] = 1; out.push(t); }
    });
    return out;
  }
  function failSave(e) { toast('Could not save. Please try again.'); if (window.console) console.error(e); }

  /* collections */
  function saveCollection(data, id) {
    var c = id ? DB.get('collections', id) : null;
    if (c) {
      c.name = data.name; c.color = data.color; c.icon = data.icon; c.parentId = data.parentId || null; c.updatedAt = now();
    } else {
      c = { id: uid(), name: data.name, color: data.color, icon: data.icon, parentId: data.parentId || null, cover: null,
        order: children(data.parentId || null).length, createdAt: now(), updatedAt: now(), deletedAt: null };
    }
    DB.put('collections', c).catch(failSave);
    return c;
  }
  function deleteCollection(id) {
    var ids = [id].concat(descendantIds(id)), t = now();
    ids.forEach(function (cid) {
      var c = DB.get('collections', cid);
      c.deletedAt = t; c.deletedBy = id; c.updatedAt = t;
      DB.put('collections', c).catch(failSave);
    });
  }
  function restoreCollection(id) {
    DB.all('collections').filter(function (c) { return c.deletedBy === id; }).forEach(function (c) {
      c.deletedAt = null; c.deletedBy = null; c.updatedAt = now();
      if (c.id === id && c.parentId) {
        var p = DB.get('collections', c.parentId);
        if (!p || p.deletedAt) c.parentId = null;
      }
      DB.put('collections', c).catch(failSave);
    });
  }
  function purgeCollection(id) {
    var group = DB.all('collections').filter(function (c) { return c.deletedBy === id; }).map(function (c) { return c.id; });
    var set = {}; group.forEach(function (g) { set[g] = 1; });
    DB.all('links').slice().forEach(function (l) { if (set[l.collectionId]) DB.remove('links', l.id); });
    group.forEach(function (g) { DB.remove('collections', g); });
  }

  /* items */
  function setItemCollections(itemId, ids) {
    var want = {}; ids.forEach(function (i) { want[i] = 1; });
    var have = {};
    DB.all('links').slice().forEach(function (l) {
      if (l.itemId !== itemId) return;
      if (!want[l.collectionId]) DB.remove('links', l.id); else have[l.collectionId] = 1;
    });
    ids.forEach(function (cid) {
      if (!have[cid]) DB.put('links', { id: itemId + ':' + cid, itemId: itemId, collectionId: cid, addedAt: now() }).catch(failSave);
    });
  }
  function createItem(data, collectionIds) {
    var t = now();
    var item = { id: uid(), type: data.type, title: data.title, url: data.url || '', domain: data.url ? domainOf(data.url) : '',
      notes: data.notes || '', tags: data.tags || [], platformId: data.url ? platformFor(data.url) : null,
      favorite: false, archived: false, createdAt: t, updatedAt: t, lastOpenedAt: null, deletedAt: null };
    DB.put('items', item).catch(failSave);
    setItemCollections(item.id, collectionIds);
    return item;
  }
  function touchItem(item) { item.updatedAt = now(); DB.put('items', item).catch(failSave); }
  function purgeItem(id) {
    DB.all('links').slice().forEach(function (l) { if (l.itemId === id) DB.remove('links', l.id); });
    DB.remove('items', id);
  }
  function dupKey(url) {
    try {
      var u = new URL(url);
      return u.hostname.replace(/^www\./, '').toLowerCase() + u.pathname.replace(/\/+$/, '') + u.search;
    } catch (e) { return url; }
  }
  function findDuplicate(url, exceptId) {
    var k = dupKey(url);
    return liveItems().filter(function (i) { return i.url && i.id !== exceptId && dupKey(i.url) === k; })[0] || null;
  }
  function purgeOld() {
    var limit = now() - 30 * DAY;
    DB.all('items').slice().forEach(function (i) { if (i.deletedAt && i.deletedAt < limit) purgeItem(i.id); });
    DB.all('collections').filter(function (c) { return c.deletedAt && c.deletedBy === c.id && c.deletedAt < limit; })
      .forEach(function (c) { purgeCollection(c.id); });
  }

  /* ---------- UI pieces ---------- */
  var form = { color: '', icon: 'folder' };
  var confirmResolve = null;
  var toastTimer;

  function toast(msg, action) {
    var t = el('toast');
    t.innerHTML = '';
    var s = document.createElement('span');
    s.textContent = msg;
    t.appendChild(s);
    t.classList.remove('act');
    if (action) {
      var b = document.createElement('button');
      b.className = 'toast-act';
      b.textContent = action.label;
      b.onclick = function () { t.classList.remove('on'); action.fn(); };
      t.appendChild(b);
      t.classList.add('act');
    }
    t.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('on'); }, action ? 5500 : 2200);
  }

  function syncScrim() {
    var on = el('sheet').classList.contains('on') || el('modal').classList.contains('on');
    el('scrim').classList.toggle('on', on);
  }
  function openSheet() { closeModal(); el('sheet').classList.add('on'); el('sheet').setAttribute('aria-hidden', 'false'); syncScrim(); }
  function closeSheet() { el('sheet').classList.remove('on'); el('sheet').setAttribute('aria-hidden', 'true'); syncScrim(); }
  function openModal(html) {
    closeSheet();
    var m = el('modal');
    m.innerHTML = '<div class="grab"></div>' + html;
    m.scrollTop = 0;
    m.classList.add('on');
    m.setAttribute('aria-hidden', 'false');
    syncScrim();
  }
  function closeModal() {
    var m = el('modal');
    m.classList.remove('on');
    m.setAttribute('aria-hidden', 'true');
    if (confirmResolve) { var r = confirmResolve; confirmResolve = null; r(false); }
    syncScrim();
  }
  function closeAll() { closeSheet(); closeModal(); }

  function confirmBox(title, text, label) {
    return new Promise(function (resolve) {
      openModal('<h2>' + esc(title) + '</h2><p class="note-hint">' + esc(text) + '</p>' +
        '<div class="actions"><button class="btn ghost" data-action="confirm-no">Cancel</button>' +
        '<button class="btn" data-action="confirm-yes">' + esc(label) + '</button></div>');
      confirmResolve = resolve;
    });
  }

  function thumbOf(item) {
    var p = item.platformId ? platform(item.platformId) : null;
    return {
      c: p ? p.color : '150,120,170',
      inner: item.type === 'note' ? ic('note') : (p ? esc(p.name.charAt(0)) : ic('link'))
    };
  }
  function metaOf(item) {
    return (item.type === 'note' ? 'Note' : (item.domain || 'Link')) + ', ' + fmtDate(item.createdAt);
  }
  function itemRow(item) {
    var t = thumbOf(item);
    return '<button class="irow" data-action="open-item" data-value="' + item.id + '">' +
      '<span class="thumb" style="--c:' + t.c + '">' + t.inner + '</span>' +
      '<span class="grow"><b>' + esc(item.title) + '</b><small>' + esc(metaOf(item)) + '</small></span>' +
      (item.favorite ? '<span class="star">' + ic('star') + '</span>' : '') + '</button>';
  }
  function itemCard(item, wide) {
    var t = thumbOf(item);
    return '<button class="icard' + (wide ? ' wide' : '') + '" data-action="open-item" data-value="' + item.id + '">' +
      '<span class="cover" style="--c:' + t.c + '">' + t.inner + '</span>' +
      '<b>' + esc(item.title) + '</b><small>' + esc(metaOf(item)) + '</small></button>';
  }
  function renderItems(list) {
    if (state.view === 'list') return list.map(itemRow).join('');
    var wideEvery = state.view === 'mixed';
    return '<div class="igrid">' + list.map(function (it, i) { return itemCard(it, wideEvery && i % 5 === 0); }).join('') + '</div>';
  }
  function emptyCard(icon, title, text) {
    return '<div class="empty center">' + ic(icon) + '<h3>' + esc(title) + '</h3><p>' + esc(text) + '</p></div>';
  }
  function colCard(c, wide) {
    var n = itemsIn(c.id).length, s = children(c.id).length;
    return '<button class="col' + (wide ? ' wide' : '') + '" style="--c:' + c.color + '" data-action="go" data-value="collection/' + c.id + '">' +
      ic(c.icon || 'folder') + '<span><h3>' + esc(c.name) + '</h3><small>' + n + (n === 1 ? ' item' : ' items') + '</small>' +
      (s ? '<small>' + s + (s === 1 ? ' subfolder' : ' subfolders') + '</small>' : '') + '</span></button>';
  }
  function byNew(a, b) { return b.createdAt - a.createdAt; }
  function missing() {
    return '<button class="back" data-action="back">' + ic('back') + 'Back</button>' + emptyCard('info', 'Not found', 'This item may have been moved to Trash.');
  }

  /* ---------- views ---------- */
  function viewHome() {
    var roots = children(null);
    var cols = roots.length
      ? '<div class="cols">' + roots.map(function (c, i) { return colCard(c, i === 0); }).join('') + '</div>'
      : '<div class="empty"><h3>Create your first collection</h3><p>Collections are your own folders, like Study or Business. One link can live in several of them.</p>' +
        '<div class="actions"><button class="btn" data-action="new-collection" data-value="">New collection</button>' +
        '<button class="btn ghost" data-action="starter">Add starters</button></div></div>';
    var live = liveItems().filter(function (i) { return !i.archived; }).sort(byNew);
    var recent = live.slice(0, 4);
    var favs = live.filter(function (i) { return i.favorite; }).slice(0, 4);
    return '' +
      '<header class="top"><div class="brand"><img class="mark" src="img/logo.png" alt="">NEXORA</div></header>' +
      '<h1 class="display">Your library</h1>' +
      '<p class="lede">Everything you save, in one place.</p>' +
      '<button class="search" data-action="go" data-value="search">' + ic('search') + '<span>Search links, files and notes</span></button>' +
      '<div class="chips">' +
        '<button class="chip" data-action="add-link" data-value="">' + ic('link') + 'Add link</button>' +
        '<button class="chip" data-action="add-note" data-value="">' + ic('note') + 'New note</button>' +
        '<button class="chip" data-action="soon" data-value="Import file">' + ic('upload') + 'Import file</button>' +
      '</div>' +
      '<div class="sec-head"><h2>Collections</h2><button class="link" data-action="new-collection" data-value="">New collection</button></div>' +
      cols +
      '<div class="sec-head"><h2>Recently added</h2></div>' +
      (recent.length ? recent.map(itemRow).join('') :
        '<div class="empty"><h3>Nothing saved yet</h3><p>Tap + to save your first link or note.</p></div>') +
      '<div class="sec-head"><h2>Favorites</h2></div>' +
      (favs.length ? favs.map(itemRow).join('') : '<div class="empty flat"><p>Open an item and tap Favorite to keep it here.</p></div>');
  }

  function viewCollection(id) {
    var c = collection(id);
    if (!c) return missing();
    var subs = children(id), items = itemsIn(id);
    var par = c.parentId ? pathOf(c.parentId) : '';
    return '' +
      '<button class="back" data-action="back">' + ic('back') + 'Back</button>' +
      '<div class="hd"><span class="thumb" style="--c:' + c.color + '">' + ic(c.icon || 'folder') + '</span><h1 class="page">' + esc(c.name) + '</h1></div>' +
      '<p class="crumb">' + (par ? esc(par) + ', ' : '') + items.length + (items.length === 1 ? ' item' : ' items') + '</p>' +
      '<div class="chips">' +
        '<button class="chip" data-action="new-collection" data-value="' + id + '">' + ic('folder') + 'Subfolder</button>' +
        '<button class="chip" data-action="add-link" data-value="' + id + '">' + ic('link') + 'Add link</button>' +
        '<button class="chip" data-action="add-note" data-value="' + id + '">' + ic('note') + 'New note</button>' +
        '<button class="chip" data-action="edit-collection" data-value="' + id + '">' + ic('edit') + 'Edit</button>' +
        '<button class="chip" data-action="delete-collection" data-value="' + id + '">' + ic('trash') + 'Delete</button>' +
      '</div>' +
      (subs.length ? '<div class="sec-head"><h2>Subfolders</h2></div><div class="cols">' + subs.map(function (s) { return colCard(s, false); }).join('') + '</div>' : '') +
      '<div class="sec-head"><h2>Items</h2></div>' +
      (items.length ? renderItems(items) : emptyCard('folder', 'Nothing here yet', 'Add a link or note to this collection.'));
  }

  function viewPlatforms() {
    var tiles = DB.all('platforms').slice().sort(function (a, b) { return a.createdAt - b.createdAt; }).map(function (p) {
      var n = liveItems().filter(function (i) { return i.platformId === p.id; }).length;
      return '<button class="plat" style="--c:' + p.color + '" data-action="go" data-value="platform/' + p.id + '">' +
        '<span class="plat-ic">' + esc(p.name.charAt(0)) + '</span><span><b>' + esc(p.name) + '</b><small>' + n + (n === 1 ? ' item' : ' items') + '</small></span></button>';
    }).join('');
    return '' +
      '<div class="title-row"><h1 class="page">Platforms</h1><p class="lede">Where your content came from.</p></div>' +
      '<div class="plats">' + tiles +
        '<button class="plat add" data-action="new-platform"><span class="plat-ic">' + ic('plus') + '</span><span><b>Add platform</b><small>Name and color</small></span></button>' +
      '</div>';
  }

  function viewPlatform(id) {
    var p = platform(id);
    if (!p) return missing();
    var items = liveItems().filter(function (i) { return i.platformId === id && !i.archived; }).sort(byNew);
    return '' +
      '<button class="back" data-action="back">' + ic('back') + 'Platforms</button>' +
      '<div class="hd"><span class="thumb" style="--c:' + p.color + '">' + esc(p.name.charAt(0)) + '</span><h1 class="page">' + esc(p.name) + '</h1></div>' +
      '<p class="crumb">' + items.length + (items.length === 1 ? ' item' : ' items') + '</p>' +
      (items.length ? renderItems(items) : emptyCard('link', 'Inbox is empty', 'Links from ' + p.name + ' will collect here.'));
  }

  var FILTERS = [
    { id: 'all', label: 'All', icon: 'folder', title: 'No items yet', text: 'Items you save will appear here.' },
    { id: 'fav', label: 'Favorites', icon: 'star', title: 'No favorites yet', text: 'Open an item and tap Favorite.' },
    { id: 'recent', label: 'Recent', icon: 'clock', title: 'Nothing opened recently', text: 'Items you open will show up here.' },
    { id: 'archive', label: 'Archived', icon: 'archive', title: 'Archive is empty', text: 'Move items you rarely use here.' },
    { id: 'trash', label: 'Trash', icon: 'trash', title: 'Trash is empty', text: 'Deleted items stay here for 30 days.' }
  ];
  var VIEWS = [
    { id: 'grid', icon: 'grid', label: 'Grid view' },
    { id: 'list', icon: 'list', label: 'List view' },
    { id: 'mixed', icon: 'mixed', label: 'Mixed view' }
  ];

  function savedList(f) {
    var l = liveItems();
    if (f === 'fav') return l.filter(function (i) { return i.favorite && !i.archived; }).sort(byNew);
    if (f === 'recent') return l.filter(function (i) { return i.lastOpenedAt; }).sort(function (a, b) { return b.lastOpenedAt - a.lastOpenedAt; }).slice(0, 50);
    if (f === 'archive') return l.filter(function (i) { return i.archived; }).sort(byNew);
    return l.filter(function (i) { return !i.archived; }).sort(byNew);
  }

  function trashHTML() {
    var items = DB.all('items').filter(function (i) { return i.deletedAt; }).sort(function (a, b) { return b.deletedAt - a.deletedAt; });
    var cols = DB.all('collections').filter(function (c) { return c.deletedAt && c.deletedBy === c.id; });
    if (!items.length && !cols.length) return emptyCard('trash', 'Trash is empty', 'Deleted items stay here for 30 days.');
    function actions(kind, id) {
      return '<button class="mini" data-action="restore" data-value="' + kind + ':' + id + '">Restore</button>' +
        '<button class="mini danger" data-action="purge" data-value="' + kind + ':' + id + '">Delete</button>';
    }
    return '<p class="note-hint">Items are removed for good after 30 days. Deleting here never touches the original YouTube, Facebook or other post.</p>' +
      cols.map(function (c) {
        return '<div class="irow"><span class="thumb" style="--c:' + c.color + '">' + ic(c.icon || 'folder') + '</span><span class="grow"><b>' + esc(c.name) +
          '</b><small>Collection, ' + daysLeft(c.deletedAt) + ' days left</small></span>' + actions('col', c.id) + '</div>';
      }).join('') +
      items.map(function (i) {
        var t = thumbOf(i);
        return '<div class="irow"><span class="thumb" style="--c:' + t.c + '">' + t.inner + '</span><span class="grow"><b>' + esc(i.title) +
          '</b><small>' + daysLeft(i.deletedAt) + ' days left</small></span>' + actions('item', i.id) + '</div>';
      }).join('');
  }

  function viewSaved() {
    var cur = FILTERS.filter(function (f) { return f.id === state.filter; })[0] || FILTERS[0];
    var seg = FILTERS.map(function (f) {
      return '<button data-action="filter" data-value="' + f.id + '" aria-pressed="' + (f.id === state.filter) + '">' + f.label + '</button>';
    }).join('');
    var views = VIEWS.map(function (v) {
      return '<button data-action="view" data-value="' + v.id + '" aria-label="' + v.label + '" aria-pressed="' + (v.id === state.view) + '">' + ic(v.icon) + '</button>';
    }).join('');
    var body;
    if (cur.id === 'trash') body = trashHTML();
    else {
      var list = savedList(cur.id);
      body = list.length ? renderItems(list) : emptyCard(cur.icon, cur.title, cur.text);
    }
    return '<div class="title-row"><h1 class="page">Saved</h1></div><div class="seg">' + seg + '</div>' +
      (cur.id === 'trash' ? '' : '<div class="views">' + views + '</div>') + body;
  }

  function viewItem(id) {
    var it = DB.get('items', id);
    if (!it || it.deletedAt) return missing();
    var t = thumbOf(it), p = it.platformId ? platform(it.platformId) : null, cols = collectionsOf(id);
    return '' +
      '<button class="back" data-action="back">' + ic('back') + 'Back</button>' +
      '<div class="hd"><span class="thumb" style="--c:' + t.c + '">' + t.inner + '</span><h1 class="page" style="font-size:24px">' + esc(it.title) + '</h1></div>' +
      '<p class="crumb">' + (p ? esc(p.name) + ', ' : '') + 'saved ' + fmtDate(it.createdAt) + '</p>' +
      (it.url ? '<a class="btn" href="' + esc(it.url) + '" target="_blank" rel="noopener" data-action="opened" data-value="' + id + '">' + ic('external') + 'Open original</a><p class="url" style="margin-top:10px">' + esc(it.url) + '</p>' : '') +
      (it.notes ? '<p class="body-text">' + esc(it.notes) + '</p>' : '') +
      ((it.tags || []).length ? '<div class="tags">' + it.tags.map(function (g) { return '<span class="tag">#' + esc(g) + '</span>'; }).join('') + '</div>' : '') +
      '<div class="group-title">In collections</div>' +
      (cols.length ? '<div class="chips" style="flex-wrap:wrap">' + cols.map(function (c) {
        return '<button class="chip" data-action="go" data-value="collection/' + c.id + '">' + ic(c.icon || 'folder') + esc(c.name) + '</button>';
      }).join('') + '</div>' : '<p class="note-hint">Not in any collection yet. Tap Edit to add one.</p>') +
      '<div class="group" style="margin-top:20px">' +
        row('star', it.favorite ? 'Remove from favorites' : 'Add to favorites', '', 'fav', id) +
        row('edit', 'Edit', '', 'edit-item', id) +
        row('archive', it.archived ? 'Unarchive' : 'Archive', '', 'archive', id) +
        row('trash', 'Move to Trash', '', 'delete-item', id) +
      '</div>';
  }

  function viewSearch() {
    return '<button class="back" data-action="back">' + ic('back') + 'Home</button>' +
      '<input id="sinput" class="sinput" type="search" placeholder="Search links, notes, tags, collections" autocomplete="off">' +
      '<div id="sresults"></div>';
  }
  function runSearch(q) {
    q = q.trim().toLowerCase();
    var out = el('sresults');
    if (!out) return;
    if (!q) { out.innerHTML = '<p class="note-hint">Type to search titles, links, notes, tags and collections.</p>'; return; }
    var items = liveItems().filter(function (i) {
      var p = i.platformId ? platform(i.platformId) : null;
      var hay = [i.title, i.url, i.domain, i.notes, (i.tags || []).join(' '), collectionsOf(i.id).map(function (c) { return c.name; }).join(' '), p ? p.name : ''].join(' ').toLowerCase();
      return hay.indexOf(q) >= 0;
    }).sort(byNew);
    var cols = liveCols().filter(function (c) { return c.name.toLowerCase().indexOf(q) >= 0; });
    if (!items.length && !cols.length) { out.innerHTML = emptyCard('search', 'No results', 'Try another word.'); return; }
    out.innerHTML = cols.map(function (c) {
      return '<button class="irow" data-action="go" data-value="collection/' + c.id + '"><span class="thumb" style="--c:' + c.color + '">' + ic(c.icon || 'folder') + '</span><span class="grow"><b>' + esc(c.name) + '</b><small>Collection</small></span></button>';
    }).join('') + items.map(itemRow).join('');
  }

  function row(icon, label, value, action, msg) {
    return '<button class="row" data-action="' + action + '" data-value="' + esc(msg) + '">' +
      '<span class="row-ic">' + ic(icon) + '</span><span class="row-label">' + label + '</span>' +
      (value ? '<span class="row-val">' + esc(value) + '</span>' : '') + ic('chev').replace('class="ic"', 'class="ic chev"') + '</button>';
  }
  function paletteName() {
    return PALETTES.filter(function (p) { return p.id === state.palette; })[0].name;
  }
  function viewSettings() {
    return '' +
      '<div class="title-row"><h1 class="page">Settings</h1></div>' +
      '<div class="group">' + row('user', 'Account', '', 'soon', 'Account') + '</div>' +
      '<div class="group">' + row('palette', 'Appearance', state.rotate ? 'Changes each time' : paletteName(), 'go', 'settings/appearance') + '</div>' +
      '<div class="group-title">Protection</div>' +
      '<div class="group">' + row('lock', 'Security and app lock', '', 'soon', 'Security') + '</div>' +
      '<div class="group-title">Your data</div>' +
      '<div class="group">' +
        row('cloud', 'Cloud sync', 'Off', 'soon', 'Cloud sync') +
        row('archive', 'Backup and restore', '', 'soon', 'Backup') +
        row('storage', 'Storage', '', 'soon', 'Storage') +
        row('exportIc', 'Export and import', '', 'soon', 'Export and import') +
      '</div>' +
      '<div class="group-title">Smart Share</div>' +
      '<div class="group">' +
        row('route', 'Smart routing rules', '', 'soon', 'Routing rules') +
        row('phone', 'Manage devices', '', 'soon', 'Devices') +
      '</div>' +
      '<div class="group">' + row('info', 'About NEXORA', VERSION, 'soon', 'NEXORA ' + VERSION) + '</div>';
  }

  function viewAppearance() {
    var themes = [['system', 'System'], ['light', 'Light'], ['dark', 'Dark']].map(function (t) {
      return '<button data-action="theme" data-value="' + t[0] + '" aria-pressed="' + (t[0] === state.theme) + '">' + t[1] + '</button>';
    }).join('');
    var pals = PALETTES.map(function (p) {
      return '<button class="pal" data-action="palette" data-value="' + p.id + '" aria-pressed="' + (!state.rotate && state.palette === p.id) + '">' +
        '<span class="dots">' + p.dots.map(function (d) { return '<i style="background:' + d + '"></i>'; }).join('') + '</span><b>' + p.name + '</b>' + ic('check') + '</button>';
    }).join('');
    return '' +
      '<button class="back" data-action="back">' + ic('back') + 'Settings</button>' +
      '<div class="title-row"><h1 class="page">Appearance</h1></div>' +
      '<div class="group-title">Mode</div><div class="seg-big">' + themes + '</div>' +
      '<div class="group-title">Colors</div>' +
      '<div class="group"><div class="row"><span class="row-ic">' + ic('palette') + '</span><span class="row-label">Change colors every time I open the app</span>' +
        '<button class="switch" data-action="rotate" aria-label="Change colors every launch" aria-pressed="' + state.rotate + '"></button></div></div>' +
      '<p class="note-hint">' + (state.rotate ? 'Now showing: ' + paletteName() + '. Tap a color set below to keep it fixed.' : 'Fixed color set. Turn the switch on to change colors on every launch.') + '</p>' +
      '<div class="group">' + pals + '</div>';
  }

  /* ---------- forms ---------- */
  function colorDots(selected, action) {
    return COLORS.map(function (c) {
      return '<button type="button" class="cdot" style="--c:' + c.c + '" aria-label="' + c.name + '" data-action="' + action + '" data-value="' + c.c + '" aria-pressed="' + (c.c === selected) + '"></button>';
    }).join('');
  }

  function openCollectionForm(id, parentId) {
    var c = id ? DB.get('collections', id) : null;
    form.color = c ? c.color : COLORS[liveCols().length % COLORS.length].c;
    form.icon = c ? (c.icon || 'folder') : 'folder';
    var parent = c ? c.parentId : (parentId || null);
    var skip = {};
    if (c) { skip[c.id] = 1; descendantIds(c.id).forEach(function (d) { skip[d] = 1; }); }
    var opts = '<option value="">Top level</option>' + liveCols().filter(function (x) { return !skip[x.id]; })
      .map(function (x) { return { id: x.id, path: pathOf(x.id) }; })
      .sort(function (a, b) { return a.path.localeCompare(b.path); })
      .map(function (x) { return '<option value="' + x.id + '"' + (x.id === parent ? ' selected' : '') + '>' + esc(x.path) + '</option>'; }).join('');
    var icons = FOLDER_ICONS.map(function (n) {
      return '<button type="button" class="icopt" aria-label="' + n + '" data-action="pick-icon" data-value="' + n + '" aria-pressed="' + (n === form.icon) + '">' + ic(n) + '</button>';
    }).join('');
    openModal('<h2>' + (c ? 'Edit collection' : (parent ? 'New subfolder' : 'New collection')) + '</h2>' +
      '<label class="field"><span>Name</span><input id="f-name" type="text" maxlength="60" placeholder="e.g. Study" value="' + esc(c ? c.name : '') + '"></label>' +
      '<div class="field"><span>Color</span><div class="colors" id="f-colors">' + colorDots(form.color, 'pick-color') + '</div></div>' +
      '<div class="field"><span>Icon</span><div class="icons" id="f-icons">' + icons + '</div></div>' +
      '<label class="field"><span>Inside</span><select id="f-parent">' + opts + '</select></label>' +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-collection" data-value="' + (id || '') + '">Save</button></div>');
  }

  function saveCollectionForm(id) {
    var name = el('f-name').value.trim();
    if (!name) { toast('Give the collection a name'); return; }
    var c = saveCollection({ name: name, color: form.color, icon: form.icon, parentId: el('f-parent').value || null }, id || null);
    closeModal();
    render();
    toast(id ? 'Collection updated' : '"' + c.name + '" created');
  }

  function openPlatformForm() {
    form.color = COLORS[DB.all('platforms').length % COLORS.length].c;
    openModal('<h2>New platform</h2>' +
      '<label class="field"><span>Name</span><input id="f-pname" type="text" maxlength="40" placeholder="e.g. Pinterest"></label>' +
      '<label class="field"><span>Website domain (optional)</span><input id="f-pdomain" type="text" autocapitalize="none" placeholder="pinterest.com"></label>' +
      '<div class="field"><span>Color</span><div class="colors" id="f-colors">' + colorDots(form.color, 'pick-color') + '</div></div>' +
      '<p class="note-hint">With a domain, links from that site go to this platform automatically.</p>' +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-platform">Save</button></div>');
  }
  function savePlatformForm() {
    var name = el('f-pname').value.trim();
    if (!name) { toast('Give the platform a name'); return; }
    var dom = el('f-pdomain').value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
    DB.put('platforms', { id: uid(), name: name, color: form.color, domains: dom ? [dom] : [], builtin: false, createdAt: now(), updatedAt: now() }).catch(failSave);
    closeModal(); render(); toast('"' + name + '" added');
  }

  function pickChips(selected) {
    var list = liveCols().map(function (c) { return { id: c.id, path: pathOf(c.id) }; })
      .sort(function (a, b) { return a.path.localeCompare(b.path); });
    if (!list.length) return '<p class="note-hint">No collections yet. This will be saved to its platform inbox.</p>';
    return '<div class="picks">' + list.map(function (c) {
      return '<button type="button" class="pick" data-action="toggle-pick" data-value="' + c.id + '" aria-pressed="' + (selected.indexOf(c.id) >= 0) + '">' + esc(c.path) + '</button>';
    }).join('') + '</div>';
  }
  function pickedCols() {
    return Array.prototype.slice.call(document.querySelectorAll('#modal .pick[aria-pressed="true"]')).map(function (b) { return b.getAttribute('data-value'); });
  }

  function openItemForm(kind, item, presetCol) {
    var sel = item ? collectionsOf(item.id).map(function (c) { return c.id; }) : (presetCol ? [presetCol] : []);
    var isLink = kind === 'link';
    openModal('<h2>' + (item ? 'Edit item' : (isLink ? 'Add link' : 'New note')) + '</h2>' +
      (isLink ? '<label class="field"><span>Link</span><input id="f-url" type="url" autocapitalize="none" autocorrect="off" placeholder="https://" value="' + esc(item ? item.url : '') + '"></label>' : '') +
      '<label class="field"><span>Title' + (isLink ? ' (optional)' : '') + '</span><input id="f-title" type="text" maxlength="140" value="' + esc(item ? item.title : '') + '"></label>' +
      '<label class="field"><span>' + (isLink ? 'Notes (optional)' : 'Note') + '</span><textarea id="f-notes" class="' + (isLink ? '' : 'tall') + '">' + esc(item ? item.notes : '') + '</textarea></label>' +
      '<label class="field"><span>Tags (separate with commas)</span><input id="f-tags" type="text" autocapitalize="none" value="' + esc(item ? (item.tags || []).join(', ') : '') + '"></label>' +
      '<div class="field"><span>Save to</span></div>' + pickChips(sel) +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-item" data-value="' + kind + ':' + (item ? item.id : '') + '">Save</button></div>');
  }

  function saveItemForm(kind, id) {
    var title = el('f-title').value.trim(), notes = el('f-notes').value.trim(), tags = parseTags(el('f-tags').value), cols = pickedCols();
    var data;
    if (kind === 'link') {
      var url = normalizeUrl(el('f-url').value);
      if (!url) { toast('Enter a valid link, like youtube.com/...'); return; }
      data = { type: 'link', title: title || domainOf(url), url: url, notes: notes, tags: tags };
      var dup = findDuplicate(url, id);
      if (dup) {
        confirmBox('Already saved', '"' + dup.title + '" has the same link. Save it again?', 'Save anyway').then(function (ok) { if (ok) commitItem(data, cols, id); });
        return;
      }
    } else {
      if (!title && !notes) { toast('Write a title or some text'); return; }
      data = { type: 'note', title: title || notes.split('\n')[0].slice(0, 60), notes: notes, tags: tags };
    }
    commitItem(data, cols, id);
  }

  function commitItem(data, cols, id) {
    closeModal();
    if (id) {
      var it = DB.get('items', id);
      it.title = data.title; it.notes = data.notes; it.tags = data.tags;
      if (data.url) { it.url = data.url; it.domain = domainOf(data.url); it.platformId = platformFor(data.url); }
      touchItem(it);
      setItemCollections(id, cols);
      render();
      toast('Changes saved');
      return;
    }
    var item = createItem(data, cols);
    render();
    toast('Saved', { label: 'Undo', fn: function () { purgeItem(item.id); render(); } });
  }

  /* ---------- router ---------- */
  function route() {
    var h = (location.hash || '#/home').replace(/^#\/?/, '');
    return (h || 'home').split('/');
  }
  function currentCollectionId() {
    var r = route();
    return r[0] === 'collection' && collection(r[1]) ? r[1] : '';
  }

  function render() {
    var r = route(), tab = r[0], html, navTab = tab;
    if (tab === 'collection') { html = viewCollection(r[1]); navTab = 'home'; }
    else if (tab === 'item') { html = viewItem(r[1]); navTab = 'home'; }
    else if (tab === 'search') { html = viewSearch(); navTab = 'home'; }
    else if (tab === 'platform') { html = viewPlatform(r[1]); navTab = 'platforms'; }
    else if (tab === 'settings' && r[1] === 'appearance') html = viewAppearance();
    else if (tab === 'settings') html = viewSettings();
    else if (tab === 'platforms') html = viewPlatforms();
    else if (tab === 'saved') html = viewSaved();
    else { navTab = 'home'; html = viewHome(); }
    el('view').innerHTML = html;
    var items = document.querySelectorAll('.nav-item');
    for (var i = 0; i < items.length; i++) {
      if (items[i].getAttribute('data-tab') === navTab) items[i].setAttribute('aria-current', 'page');
      else items[i].removeAttribute('aria-current');
    }
    if (tab === 'search') { var si = el('sinput'); if (si) { runSearch(''); si.focus(); } }
  }

  /* ---------- add sheet ---------- */
  var ADD_OPTIONS = [
    ['link', 'Add link', 'add-link'], ['image', 'Add image', 'soon'], ['file', 'Add document', 'soon'],
    ['video', 'Add video', 'soon'], ['note', 'Create note', 'add-note'], ['upload', 'Import file', 'soon']
  ];
  function buildSheet() {
    el('sheet-items').innerHTML = ADD_OPTIONS.map(function (o) {
      return '<button class="opt" data-action="' + o[2] + '" data-value="' + (o[2] === 'soon' ? o[1] : '') + '">' + ic(o[0]) + o[1] + '</button>';
    }).join('');
  }

  /* ---------- actions ---------- */
  function startStarters() {
    var names = ['Study', 'Business', 'Personal', 'Ideas'], icons = ['bookmark', 'folder', 'lock', 'star'];
    names.forEach(function (n, i) { saveCollection({ name: n, color: COLORS[i * 2 % COLORS.length].c, icon: icons[i], parentId: null }, null); });
    render();
    toast('Starter collections added');
  }

  function onAction(a, v) {
    var parts, it, c;
    switch (a) {
      case 'tab': closeAll(); location.replace('#/' + v); break;
      case 'go': location.hash = '#/' + v; break;
      case 'back': history.back(); break;
      case 'add': openSheet(); break;
      case 'close-sheet': closeAll(); break;
      case 'soon': closeAll(); toast(v + ' is coming in the next step'); break;
      case 'theme': state.theme = v; store.set('theme', v); applyTheme(); render(); break;
      case 'palette':
        state.palette = v; state.rotate = false; store.set('palette', v); store.set('rotate', '0'); applyTheme(); render(); break;
      case 'rotate':
        state.rotate = !state.rotate; store.set('rotate', state.rotate ? '1' : '0');
        if (!state.rotate) store.set('palette', state.palette);
        render();
        toast(state.rotate ? 'Colors will change each time you open the app' : 'Colors are now fixed');
        break;
      case 'filter': state.filter = v; render(); break;
      case 'view': state.view = v; store.set('view', v); render(); break;
      case 'new-collection': openCollectionForm(null, v || null); break;
      case 'edit-collection': openCollectionForm(v, null); break;
      case 'save-collection': saveCollectionForm(v); break;
      case 'starter': startStarters(); break;
      case 'pick-color': case 'pick-icon': {
        var box = a === 'pick-color' ? 'f-colors' : 'f-icons';
        if (a === 'pick-color') form.color = v; else form.icon = v;
        Array.prototype.forEach.call(el(box).children, function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-value') === v ? 'true' : 'false'); });
        break;
      }
      case 'toggle-pick': {
        var btn = document.querySelector('#modal .pick[data-value="' + v + '"]');
        if (btn) btn.setAttribute('aria-pressed', btn.getAttribute('aria-pressed') === 'true' ? 'false' : 'true');
        break;
      }
      case 'add-link': openItemForm('link', null, v || currentCollectionId()); break;
      case 'add-note': openItemForm('note', null, v || currentCollectionId()); break;
      case 'edit-item': openItemForm(DB.get('items', v).type, DB.get('items', v), null); break;
      case 'save-item': parts = v.split(':'); saveItemForm(parts[0], parts[1] || null); break;
      case 'new-platform': openPlatformForm(); break;
      case 'save-platform': savePlatformForm(); break;
      case 'open-item':
        it = DB.get('items', v); it.lastOpenedAt = now(); DB.put('items', it).catch(failSave);
        location.hash = '#/item/' + v; break;
      case 'opened': it = DB.get('items', v); if (it) { it.lastOpenedAt = now(); DB.put('items', it).catch(failSave); } break;
      case 'fav': it = DB.get('items', v); it.favorite = !it.favorite; touchItem(it); render(); toast(it.favorite ? 'Added to favorites' : 'Removed from favorites'); break;
      case 'archive': it = DB.get('items', v); it.archived = !it.archived; touchItem(it); render(); toast(it.archived ? 'Archived' : 'Moved back to your library'); break;
      case 'delete-item':
        it = DB.get('items', v); it.deletedAt = now(); touchItem(it);
        history.back();
        toast('Moved to Trash', { label: 'Undo', fn: function () { it.deletedAt = null; touchItem(it); render(); } });
        break;
      case 'delete-collection':
        c = collection(v);
        confirmBox('Delete "' + c.name + '"?', 'It and its subfolders move to Trash for 30 days. The items inside are not deleted.', 'Move to Trash').then(function (ok) {
          if (!ok) return;
          deleteCollection(v);
          if (currentCollectionId() === v) history.back(); else render();
          toast('Moved to Trash', { label: 'Undo', fn: function () { restoreCollection(v); render(); } });
        });
        break;
      case 'restore':
        parts = v.split(':');
        if (parts[0] === 'col') restoreCollection(parts[1]);
        else { it = DB.get('items', parts[1]); it.deletedAt = null; touchItem(it); }
        render(); toast('Restored'); break;
      case 'purge':
        parts = v.split(':');
        confirmBox('Delete for good?', 'This cannot be undone. Only your NEXORA copy is removed, never the original post or video.', 'Delete').then(function (ok) {
          if (!ok) return;
          if (parts[0] === 'col') purgeCollection(parts[1]); else purgeItem(parts[1]);
          render(); toast('Deleted');
        });
        break;
      case 'confirm-yes': { var r = confirmResolve; confirmResolve = null; closeModal(); if (r) r(true); break; }
      case 'confirm-no': closeModal(); break;
    }
  }

  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-action]') : null;
    if (!t) return;
    onAction(t.getAttribute('data-action'), t.getAttribute('data-value'));
  });
  document.addEventListener('input', function (e) {
    if (e.target && e.target.id === 'sinput') runSearch(e.target.value);
  });
  window.addEventListener('hashchange', function () { closeAll(); render(); window.scrollTo(0, 0); });

  /* ---------- start ---------- */
  function seedPlatforms() {
    SEED_PLATFORMS.forEach(function (p, i) {
      if (!DB.get('platforms', p.id)) {
        DB.put('platforms', { id: p.id, name: p.name, color: p.color, domains: p.domains, builtin: true, createdAt: 1000 + i, updatedAt: 1000 + i });
      }
    });
  }
  function init() {
    var holders = document.querySelectorAll('[data-icon]');
    for (var i = 0; i < holders.length; i++) holders[i].innerHTML = ic(holders[i].getAttribute('data-icon'));
    buildSheet();
    DB.open().then(function () {
      seedPlatforms();
      purgeOld();
      render();
      if (!DB.persistent()) toast('Storage is not available. Changes will not be kept.');
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
