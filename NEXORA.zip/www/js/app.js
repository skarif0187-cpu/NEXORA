/* NEXORA - step 1: app shell, navigation, theme system */
(function () {
  'use strict';

  var VERSION = '0.1 (step 1)';

  var ICONS = {
    home: '<path d="M4 11l8-6.5L20 11v8a1 1 0 0 1-1 1h-4v-5h-6v5H5a1 1 0 0 1-1-1z"/>',
    grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.8"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    bookmark: '<path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z"/>',
    sliders: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/>',
    folder: '<path d="M3.5 7.5A1.5 1.5 0 0 1 5 6h4l2 2.2h8a1.5 1.5 0 0 1 1.5 1.5v8.3a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 18z"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    image: '<rect x="4" y="5" width="16" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M5 17l4.5-4.5 3.5 3.5 2.5-2.5L20 16"/>',
    file: '<path d="M7 3.5h6.5L18 8v11.5a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-15a1 1 0 0 1 1-1z"/><path d="M13.5 3.5V8H18"/>',
    video: '<rect x="4" y="6" width="16" height="12" rx="3"/><path d="M10.5 9.5v5l4-2.5z"/>',
    note: '<path d="M6 4.5h12a1 1 0 0 1 1 1V16l-4 4H6a1 1 0 0 1-1-1V5.5a1 1 0 0 1 1-1z"/><path d="M8.5 9h7M8.5 12.5h5"/>',
    upload: '<path d="M12 16V5M7.5 9.5L12 5l4.5 4.5"/><path d="M5 15v3a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3"/>',
    chev: '<path d="M9.5 6l6 6-6 6"/>',
    back: '<path d="M14.5 6l-6 6 6 6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    user: '<circle cx="12" cy="8.5" r="3.5"/><path d="M5 19.5c.8-3.6 3.6-5.5 7-5.5s6.2 1.9 7 5.5"/>',
    palette: '<path d="M12 4a8 8 0 1 0 0 16c1.2 0 1.8-.8 1.8-1.6 0-1.3-1-1.4-1-2.6 0-.9.7-1.5 1.6-1.5H16a4 4 0 0 0 4-4C20 6.9 16.4 4 12 4z"/><circle cx="8.5" cy="11" r="1"/><circle cx="12" cy="8" r="1"/><circle cx="15.5" cy="10" r="1"/>',
    lock: '<rect x="5" y="10.5" width="14" height="9.5" rx="2.5"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
    cloud: '<path d="M7.5 18.5a4 4 0 0 1-.6-7.95A5.5 5.5 0 0 1 17.5 9.5a4.5 4.5 0 0 1-.5 9z"/>',
    archive: '<rect x="4" y="5" width="16" height="4.5" rx="1.5"/><path d="M5.5 9.5V18a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V9.5M10 13h4"/>',
    storage: '<ellipse cx="12" cy="6.5" rx="7" ry="2.8"/><path d="M5 6.5v11c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8v-11"/><path d="M5 12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8"/>',
    route: '<path d="M4 7h4l8 10h4M4 17h4l2.5-3.2M13.5 10.2L16 7h4"/><path d="M18 5l2 2-2 2M18 15l2 2-2 2"/>',
    phone: '<rect x="7" y="3.5" width="10" height="17" rx="2.5"/><path d="M11 17.5h2"/>',
    exportIc: '<path d="M12 4v11M7.5 10.5L12 15l4.5-4.5"/><path d="M5 17v1.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V17"/>',
    info: '<circle cx="12" cy="12" r="8"/><path d="M12 11v5M12 8v.1"/>',
    star: '<path d="M12 4.5l2.2 4.6 5 .7-3.6 3.5.9 5-4.5-2.4-4.5 2.4.9-5L4.8 9.8l5-.7z"/>',
    list: '<path d="M5 7h14M5 12h14M5 17h14"/>',
    mixed: '<rect x="4" y="4" width="16" height="7" rx="1.8"/><rect x="4" y="14" width="7" height="6" rx="1.8"/><rect x="14" y="14" width="6" height="6" rx="1.8"/>',
    trash: '<path d="M5 7h14M10 7V5h4v2M7 7l.8 12a1 1 0 0 0 1 .9h6.4a1 1 0 0 0 1-.9L17 7"/>',
    clock: '<circle cx="12" cy="12" r="8"/><path d="M12 8v4.5l3 1.5"/>'
  };

  function ic(name) {
    return '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';
  }

  /* ---------- storage + theme ---------- */
  var store = {
    get: function (k, d) {
      try { var v = localStorage.getItem('nexora.' + k); return v === null ? d : v; } catch (e) { return d; }
    },
    set: function (k, v) {
      try { localStorage.setItem('nexora.' + k, v); } catch (e) { /* storage unavailable */ }
    }
  };

  var ACCENTS = [
    { id: 'nexora', name: 'Nexora', color: '#1F6BFF' },
    { id: 'lavender', name: 'Lavender', color: '#7B6CF0' },
    { id: 'sage', name: 'Sage', color: '#4F9A78' },
    { id: 'sunset', name: 'Sunset', color: '#EE6A3C' },
    { id: 'rose', name: 'Rose', color: '#E04E7B' }
  ];

  var state = {
    theme: store.get('theme', 'system'),
    accent: store.get('accent', 'nexora'),
    filter: 'all',
    view: store.get('view', 'mixed')
  };

  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function applyTheme() {
    var dark = mq ? mq.matches : true;
    var mode = state.theme === 'system' ? (dark ? 'dark' : 'light') : state.theme;
    var root = document.documentElement;
    root.setAttribute('data-mode', mode);
    root.setAttribute('data-accent', state.accent);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', mode === 'dark' ? '#030814' : '#F2F6FE');
  }
  if (mq) {
    if (mq.addEventListener) mq.addEventListener('change', applyTheme);
    else if (mq.addListener) mq.addListener(applyTheme);
  }
  applyTheme();

  /* ---------- sample data (replaced by the database in step 2) ---------- */
  var COLLECTIONS = [
    { name: 'Study', sub: 3, c: '31,107,255' },
    { name: 'Business', sub: 3, c: '236,150,20' },
    { name: 'Personal', sub: 3, c: '34,160,116' },
    { name: 'Ideas', sub: 0, c: '139,108,240' }
  ];
  var PLATFORMS = [
    { name: 'YouTube', c: '255,59,48' },
    { name: 'Facebook', c: '24,119,242' },
    { name: 'TikTok', c: '20,190,200' },
    { name: 'WhatsApp', c: '37,190,95' },
    { name: 'Instagram', c: '225,48,108' },
    { name: 'Websites', c: '31,107,255' },
    { name: 'Documents', c: '236,150,20' }
  ];

  /* ---------- views ---------- */
  function viewHome() {
    var cols = COLLECTIONS.map(function (c, i) {
      var subs = c.sub === 0 ? '' : '<small>' + c.sub + ' subfolders</small>';
      return '<button class="col' + (i === 0 ? ' wide' : '') + '" style="--c:' + c.c + '" data-action="soon" data-value="Opening collections">' +
        ic('folder') +
        '<span><h3>' + c.name + '</h3><small>0 items</small>' + subs + '</span></button>';
    }).join('');

    return '' +
      '<header class="top"><div class="brand"><img class="mark" src="img/logo.png" alt="">NEXORA</div></header>' +
      '<h1 class="display">Your library</h1>' +
      '<p class="lede">Everything you save, in one place.</p>' +
      '<button class="search" data-action="soon" data-value="Search">' + ic('search') + '<span>Search links, files and notes</span></button>' +
      '<div class="chips">' +
        '<button class="chip" data-action="soon" data-value="Add link">' + ic('link') + 'Add link</button>' +
        '<button class="chip" data-action="soon" data-value="New note">' + ic('note') + 'New note</button>' +
        '<button class="chip" data-action="soon" data-value="Import file">' + ic('upload') + 'Import file</button>' +
      '</div>' +
      '<div class="sec-head"><h2>Collections</h2><button class="link" data-action="soon" data-value="New collection">New collection</button></div>' +
      '<div class="cols">' + cols + '</div>' +
      '<div class="sec-head"><h2>Recently added</h2></div>' +
      '<div class="empty"><h3>Nothing saved yet</h3><p>Share a link from YouTube, TikTok or your browser, or tap + to add something.</p>' +
        '<button class="btn" data-action="add">Add your first item</button></div>' +
      '<div class="sec-head"><h2>Favorites</h2></div>' +
      '<div class="empty flat"><p>Tap the star on any item to keep it here.</p></div>';
  }

  function viewPlatforms() {
    var tiles = PLATFORMS.map(function (p) {
      return '<button class="plat" style="--c:' + p.c + '" data-action="soon" data-value="' + p.name + ' inbox">' +
        '<span class="plat-ic">' + p.name.charAt(0) + '</span><span><b>' + p.name + '</b><small>0 items</small></span></button>';
    }).join('');
    return '' +
      '<div class="title-row"><h1 class="page">Platforms</h1><p class="lede">Where your content came from.</p></div>' +
      '<div class="plats">' + tiles +
        '<button class="plat add" data-action="soon" data-value="Custom platforms"><span class="plat-ic">' + ic('plus') + '</span><span><b>Add platform</b><small>Name, icon, color</small></span></button>' +
      '</div>';
  }

  var FILTERS = [
    { id: 'all', label: 'All', icon: 'folder', title: 'No items yet', text: 'Items you save will appear here.' },
    { id: 'fav', label: 'Favorites', icon: 'star', title: 'No favorites yet', text: 'Tap the star on an item to add it here.' },
    { id: 'recent', label: 'Recent', icon: 'clock', title: 'Nothing opened recently', text: 'Items you open will show up here.' },
    { id: 'archive', label: 'Archived', icon: 'archive', title: 'Archive is empty', text: 'Move items you rarely use here.' },
    { id: 'trash', label: 'Trash', icon: 'trash', title: 'Trash is empty', text: 'Deleted items stay here for 30 days.' }
  ];
  var VIEWS = [
    { id: 'grid', icon: 'grid', label: 'Grid view' },
    { id: 'list', icon: 'list', label: 'List view' },
    { id: 'mixed', icon: 'mixed', label: 'Mixed view' }
  ];

  function viewSaved() {
    var cur = FILTERS.filter(function (f) { return f.id === state.filter; })[0] || FILTERS[0];
    var seg = FILTERS.map(function (f) {
      return '<button data-action="filter" data-value="' + f.id + '" aria-pressed="' + (f.id === state.filter) + '">' + f.label + '</button>';
    }).join('');
    var views = VIEWS.map(function (v) {
      return '<button data-action="view" data-value="' + v.id + '" aria-label="' + v.label + '" aria-pressed="' + (v.id === state.view) + '">' + ic(v.icon) + '</button>';
    }).join('');
    return '' +
      '<div class="title-row"><h1 class="page">Saved</h1></div>' +
      '<div class="seg">' + seg + '</div>' +
      '<div class="views">' + views + '</div>' +
      '<div class="empty center">' + ic(cur.icon) + '<h3>' + cur.title + '</h3><p>' + cur.text + '</p></div>';
  }

  function row(icon, label, value, action, msg) {
    return '<button class="row" data-action="' + action + '" data-value="' + msg + '">' +
      '<span class="row-ic">' + ic(icon) + '</span><span class="row-label">' + label + '</span>' +
      (value ? '<span class="row-val">' + value + '</span>' : '') + ic('chev').replace('class="ic"', 'class="ic chev"') + '</button>';
  }

  function themeName() { return { system: 'System', light: 'Light', dark: 'Dark' }[state.theme]; }
  function accentName() {
    return ACCENTS.filter(function (a) { return a.id === state.accent; })[0].name;
  }

  function viewSettings() {
    return '' +
      '<div class="title-row"><h1 class="page">Settings</h1></div>' +
      '<div class="group">' + row('user', 'Account', '', 'soon', 'Account') + '</div>' +
      '<div class="group">' + row('palette', 'Appearance', themeName() + ', ' + accentName(), 'go', 'settings/appearance') + '</div>' +
      '<div class="group-title">Protection</div>' +
      '<div class="group">' + row('lock', 'Security and app lock', '', 'soon', 'Security') + '</div>' +
      '<div class="group-title">Your data</div>' +
      '<div class="group">' +
        row('cloud', 'Cloud sync', 'Off', 'soon', 'Cloud sync') +
        row('archive', 'Backup and restore', '', 'soon', 'Backup') +
        row('storage', 'Storage', '', 'soon', 'Storage') +
        row('exportIc', 'Export and import', '', 'soon', 'Export and import') +
      '</div>' +
      '<div class="group-title">Smart Share</div>' +
      '<div class="group">' +
        row('route', 'Smart routing rules', '', 'soon', 'Routing rules') +
        row('phone', 'Manage devices', '', 'soon', 'Devices') +
      '</div>' +
      '<div class="group">' + row('info', 'About NEXORA', VERSION, 'soon', 'NEXORA ' + VERSION) + '</div>';
  }

  function viewAppearance() {
    var themes = [['system', 'System'], ['light', 'Light'], ['dark', 'Dark']].map(function (t) {
      return '<button data-action="theme" data-value="' + t[0] + '" aria-pressed="' + (t[0] === state.theme) + '">' + t[1] + '</button>';
    }).join('');
    var sw = ACCENTS.map(function (a) {
      return '<button class="sw" style="--s:' + a.color + '" data-action="accent" data-value="' + a.id + '" aria-pressed="' + (a.id === state.accent) + '">' +
        '<i>' + ic('check') + '</i>' + a.name + '</button>';
    }).join('');
    return '' +
      '<button class="back" data-action="back">' + ic('back') + 'Settings</button>' +
      '<div class="title-row"><h1 class="page">Appearance</h1></div>' +
      '<div class="group-title">Theme</div>' +
      '<div class="seg-big">' + themes + '</div>' +
      '<div class="group-title">Accent color</div>' +
      '<div class="group"><div class="swatches">' + sw + '</div></div>' +
      '<div class="group-title">Preview</div>' +
      '<div class="group"><div class="preview"><span class="btn">Save</span><span class="chip">Study</span></div></div>';
  }

  /* ---------- router ---------- */
  function currentRoute() {
    var h = (location.hash || '#/home').replace(/^#\/?/, '');
    return h || 'home';
  }

  function render() {
    var parts = currentRoute().split('/');
    var tab = parts[0];
    var view = document.getElementById('view');
    var html;
    if (tab === 'settings' && parts[1] === 'appearance') html = viewAppearance();
    else if (tab === 'settings') html = viewSettings();
    else if (tab === 'platforms') html = viewPlatforms();
    else if (tab === 'saved') html = viewSaved();
    else { tab = 'home'; html = viewHome(); }
    view.innerHTML = html;

    var items = document.querySelectorAll('.nav-item');
    for (var i = 0; i < items.length; i++) {
      if (items[i].getAttribute('data-tab') === tab) items[i].setAttribute('aria-current', 'page');
      else items[i].removeAttribute('aria-current');
    }
  }

  /* ---------- add sheet + toast ---------- */
  var ADD_OPTIONS = [
    ['link', 'Add link'], ['image', 'Add image'], ['file', 'Add document'],
    ['video', 'Add video'], ['note', 'Create note'], ['upload', 'Import file']
  ];

  function buildSheet() {
    document.getElementById('sheet-items').innerHTML = ADD_OPTIONS.map(function (o) {
      return '<button class="opt" data-action="soon" data-value="' + o[1] + '">' + ic(o[0]) + o[1] + '</button>';
    }).join('');
  }

  function setSheet(open) {
    document.getElementById('sheet').classList.toggle('on', open);
    document.getElementById('sheet').setAttribute('aria-hidden', open ? 'false' : 'true');
    document.getElementById('scrim').classList.toggle('on', open);
  }

  var toastTimer;
  function toast(msg) {
    var t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('on'); }, 2200);
  }

  /* ---------- events ---------- */
  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-action]') : null;
    if (!el) return;
    var a = el.getAttribute('data-action');
    var v = el.getAttribute('data-value');
    switch (a) {
      case 'tab': setSheet(false); location.replace('#/' + v); break;
      case 'go': location.hash = '#/' + v; break;
      case 'back': history.back(); break;
      case 'add': setSheet(true); break;
      case 'close-sheet': setSheet(false); break;
      case 'soon': setSheet(false); toast(v + ' is coming in a later step'); break;
      case 'theme': state.theme = v; store.set('theme', v); applyTheme(); render(); break;
      case 'accent': state.accent = v; store.set('accent', v); applyTheme(); render(); break;
      case 'filter': state.filter = v; render(); break;
      case 'view': state.view = v; store.set('view', v); render(); break;
    }
  });
  window.addEventListener('hashchange', function () { setSheet(false); render(); window.scrollTo(0, 0); });

  /* ---------- start ---------- */
  function init() {
    var holders = document.querySelectorAll('[data-icon]');
    for (var i = 0; i < holders.length; i++) {
      holders[i].innerHTML = ic(holders[i].getAttribute('data-icon'));
    }
    buildSheet();
    render();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
