/* NEXORA local database (IndexedDB) with an in-memory copy for instant screens.
   Stores: collections, items, links (item <-> collection), platforms.
   Every record has createdAt/updatedAt/deletedAt so cloud sync can be added later. */
var NexoraDB = (function () {
  'use strict';
  var NAME = 'nexora', VERSION = 3;
  var STORES = ['collections', 'items', 'links', 'platforms', 'rules'];
  var db = null;
  var listener = null;
  var mem = { collections: [], items: [], links: [], platforms: [], rules: [] };

  function indexOf(arr, id) {
    for (var i = 0; i < arr.length; i++) if (arr[i].id === id) return i;
    return -1;
  }

  function loadAll() {
    return Promise.all(STORES.map(function (s) {
      return new Promise(function (resolve) {
        var rq = db.transaction(s).objectStore(s).getAll();
        rq.onsuccess = function () { mem[s] = rq.result || []; resolve(); };
        rq.onerror = function () { resolve(); };
      });
    }));
  }

  function open() {
    return new Promise(function (resolve) {
      if (!window.indexedDB) { resolve(); return; }
      var rq;
      try { rq = indexedDB.open(NAME, VERSION); } catch (e) { resolve(); return; }
      rq.onupgradeneeded = function () {
        var d = rq.result;
        STORES.concat(['files']).forEach(function (s) {
          if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: 'id' });
        });
      };
      rq.onsuccess = function () { db = rq.result; loadAll().then(resolve); };
      rq.onerror = function () { resolve(); };
    });
  }

  function put(store, obj, silent) {
    var i = indexOf(mem[store], obj.id);
    if (i < 0) mem[store].push(obj); else mem[store][i] = obj;
    if (!silent && listener) listener(store, obj.id);
    if (!db) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).put(obj);
      tx.oncomplete = function () { resolve(); };
      tx.onerror = function () { reject(tx.error); };
    });
  }

  function remove(store, id, silent) {
    var i = indexOf(mem[store], id);
    if (i >= 0) mem[store].splice(i, 1);
    if (!silent && listener) listener(store, id);
    if (!db) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).delete(id);
      tx.oncomplete = function () { resolve(); };
      tx.onerror = function () { reject(tx.error); };
    });
  }

  return {
    open: open,
    put: put,
    remove: remove,
    all: function (s) { return mem[s]; },
    get: function (s, id) { var i = indexOf(mem[s], id); return i < 0 ? null : mem[s][i]; },
    setListener: function (fn) { listener = fn; },
    /* files (photos, PDFs, ...) live only on this phone; they are read one at a time, never all in memory */
    putFile: function (rec) {
      return new Promise(function (resolve, reject) {
        if (!db) { reject(new Error('Storage unavailable')); return; }
        var tx = db.transaction('files', 'readwrite');
        tx.objectStore('files').put(rec);
        tx.oncomplete = function () { resolve(); };
        tx.onerror = function () { reject(tx.error); };
        tx.onabort = function () { reject(tx.error || new Error('Storage full')); };
      });
    },
    getFile: function (id) {
      return new Promise(function (resolve) {
        if (!db) { resolve(null); return; }
        var rq = db.transaction('files').objectStore('files').get(id);
        rq.onsuccess = function () { resolve(rq.result || null); };
        rq.onerror = function () { resolve(null); };
      });
    },
    removeFile: function (id) {
      return new Promise(function (resolve) {
        if (!db) { resolve(); return; }
        var tx = db.transaction('files', 'readwrite');
        tx.objectStore('files').delete(id);
        tx.oncomplete = function () { resolve(); };
        tx.onerror = function () { resolve(); };
      });
    },
    persistent: function () { return !!db; }
  };
})();
