/* NEXORA - step 2: collections, items, trash, search, themes */
(function () {
  'use strict';

  var VERSION = '0.9';
  var DAY = 86400000;
  var DB = NexoraDB;

  var ICONS = {
    home: '<path d="M4 11l8-6.5L20 11v8a1 1 0 0 1-1 1h-4v-5h-6v5H5a1 1 0 0 1-1-1z"/>',
    grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.8"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    bookmark: '<path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z"/>',
    sliders: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/>',
    folder: '<path d="M3.5 7.5A1.5 1.5 0 0 1 5 6h4l2 2.2h8a1.5 1.5 0 0 1 1.5 1.5v8.3a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 18z"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    image: '<rect x="4" y="5" width="16" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M5 17l4.5-4.5 3.5 3.5 2.5-2.5L20 16"/>',
    file: '<path d="M7 3.5h6.5L18 8v11.5a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-15a1 1 0 0 1 1-1z"/><path d="M13.5 3.5V8H18"/>',
    video: '<rect x="4" y="6" width="16" height="12" rx="3"/><path d="M10.5 9.5v5l4-2.5z"/>',
    note: '<path d="M6 4.5h12a1 1 0 0 1 1 1V16l-4 4H6a1 1 0 0 1-1-1V5.5a1 1 0 0 1 1-1z"/><path d="M8.5 9h7M8.5 12.5h5"/>',
    upload: '<path d="M12 16V5M7.5 9.5L12 5l4.5 4.5"/><path d="M5 15v3a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3"/>',
    chev: '<path d="M9.5 6l6 6-6 6"/>',
    back: '<path d="M14.5 6l-6 6 6 6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    user: '<circle cx="12" cy="8.5" r="3.5"/><path d="M5 19.5c.8-3.6 3.6-5.5 7-5.5s6.2 1.9 7 5.5"/>',
    palette: '<path d="M12 4a8 8 0 1 0 0 16c1.2 0 1.8-.8 1.8-1.6 0-1.3-1-1.4-1-2.6 0-.9.7-1.5 1.6-1.5H16a4 4 0 0 0 4-4C20 6.9 16.4 4 12 4z"/><circle cx="8.5" cy="11" r="1"/><circle cx="12" cy="8" r="1"/><circle cx="15.5" cy="10" r="1"/>',
    lock: '<rect x="5" y="10.5" width="14" height="9.5" rx="2.5"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
    cloud: '<path d="M7.5 18.5a4 4 0 0 1-.6-7.95A5.5 5.5 0 0 1 17.5 9.5a4.5 4.5 0 0 1-.5 9z"/>',
    archive: '<rect x="4" y="5" width="16" height="4.5" rx="1.5"/><path d="M5.5 9.5V18a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V9.5M10 13h4"/>',
    storage: '<ellipse cx="12" cy="6.5" rx="7" ry="2.8"/><path d="M5 6.5v11c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8v-11"/><path d="M5 12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8"/>',
    route: '<path d="M4 7h4l8 10h4M4 17h4l2.5-3.2M13.5 10.2L16 7h4"/><path d="M18 5l2 2-2 2M18 15l2 2-2 2"/>',
    phone: '<rect x="7" y="3.5" width="10" height="17" rx="2.5"/><path d="M11 17.5h2"/>',
    exportIc: '<path d="M12 4v11M7.5 10.5L12 15l4.5-4.5"/><path d="M5 17v1.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V17"/>',
    info: '<circle cx="12" cy="12" r="8"/><path d="M12 11v5M12 8v.1"/>',
    star: '<path d="M12 4.5l2.2 4.6 5 .7-3.6 3.5.9 5-4.5-2.4-4.5 2.4.9-5L4.8 9.8l5-.7z"/>',
    list: '<path d="M5 7h14M5 12h14M5 17h14"/>',
    mixed: '<rect x="4" y="4" width="16" height="7" rx="1.8"/><rect x="4" y="14" width="7" height="6" rx="1.8"/><rect x="14" y="14" width="6" height="6" rx="1.8"/>',
    trash: '<path d="M5 7h14M10 7V5h4v2M7 7l.8 12a1 1 0 0 0 1 .9h6.4a1 1 0 0 0 1-.9L17 7"/>',
    clock: '<circle cx="12" cy="12" r="8"/><path d="M12 8v4.5l3 1.5"/>',
    edit: '<path d="M5 19l1-4L16 5l3 3L9 18z"/>',
    external: '<path d="M14 5h5v5M19 5l-8 8M18 14v4a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h4"/>'
  };
  var FOLDER_ICONS = ['folder', 'star', 'bookmark', 'note', 'video', 'image', 'lock', 'cloud'];
  var COLORS = [
    { name: 'Jade', c: '62,160,120' }, { name: 'Gold', c: '212,168,60' },
    { name: 'Clay', c: '196,120,96' }, { name: 'Steel', c: '110,140,190' },
    { name: 'Rose', c: '196,76,108' }, { name: 'Plum', c: '150,120,170' },
    { name: 'Sage', c: '130,160,140' }, { name: 'Copper', c: '210,118,74' }
  ];
  var PALETTES = [
    { id: 'emerald', name: 'Emerald and Champagne', dots: ['#0D2119', '#F4EBD6', '#D8B455'] },
    { id: 'burgundy', name: 'Burgundy and Bronze', dots: ['#220D16', '#F3E6CF', '#D08A45'] },
    { id: 'midnight', name: 'Midnight and Brass', dots: ['#141B2B', '#EFE7D3', '#C9996B'] },
    { id: 'espresso', name: 'Espresso and Copper', dots: ['#1E1613', '#F2E6DA', '#D2764A'] },
    { id: 'nexora', name: 'Nexora Blue', dots: ['#0B1530', '#EAF2FF', '#1F6BFF'] }
  ];
  var SEED_PLATFORMS = [
    { id: 'youtube', name: 'YouTube', color: '255,59,48', domains: ['youtube.com', 'youtu.be'] },
    { id: 'facebook', name: 'Facebook', color: '24,119,242', domains: ['facebook.com', 'fb.watch', 'fb.com'] },
    { id: 'tiktok', name: 'TikTok', color: '20,190,200', domains: ['tiktok.com'] },
    { id: 'whatsapp', name: 'WhatsApp', color: '37,190,95', domains: ['whatsapp.com', 'wa.me'] },
    { id: 'instagram', name: 'Instagram', color: '225,48,108', domains: ['instagram.com'] },
    { id: 'web', name: 'Websites', color: '110,140,190', domains: [] },
    { id: 'docs', name: 'Documents', color: '212,168,60', domains: [] }
  ];

  function ic(name) {
    return '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || ICONS.folder) + '</svg>';
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function el(id) { return document.getElementById(id); }
  function uid() {
    try { if (window.crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) { /* fall through */ }
    return 'id' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }
  function now() { return Date.now(); }
  function fmtDate(ts) {
    try { return new Date(ts).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }); } catch (e) { return ''; }
  }
  function daysLeft(ts) { return Math.max(0, 30 - Math.floor((now() - ts) / DAY)); }

  /* ---------- storage + theme ---------- */
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('nexora.' + k); return v === null ? d : v; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('nexora.' + k, v); } catch (e) { /* ignore */ } }
  };
  var state = {
    theme: store.get('theme', 'system'),
    palette: store.get('palette', 'emerald'),
    rotate: store.get('rotate', '1') === '1',
    filter: 'all',
    view: store.get('view', 'mixed'),
    kind: 'all',
    sort: store.get('sort', 'new')
  };
  if (state.rotate) {
    var lastP = store.get('last', '');
    var pool = PALETTES.filter(function (p) { return p.id !== lastP; });
    var chosen = pool[Math.floor(Math.random() * pool.length)];
    state.palette = chosen.id;
    store.set('last', chosen.id);
  }
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function applyTheme() {
    var dark = mq ? mq.matches : true;
    var mode = state.theme === 'system' ? (dark ? 'dark' : 'light') : state.theme;
    var root = document.documentElement;
    root.setAttribute('data-mode', mode);
    root.setAttribute('data-palette', state.palette);
    var meta = document.querySelector('meta[name="theme-color"]');
    var bg = getComputedStyle(root).getPropertyValue('--bg').trim();
    if (meta && bg) meta.setAttribute('content', bg);
  }
  if (mq) {
    if (mq.addEventListener) mq.addEventListener('change', applyTheme);
    else if (mq.addListener) mq.addListener(applyTheme);
  }
  applyTheme();

  /* ---------- data helpers ---------- */
  function liveCols() { return DB.all('collections').filter(function (c) { return !c.deletedAt; }); }
  function byOrder(a, b) { return (a.order || 0) - (b.order || 0) || a.createdAt - b.createdAt; }
  function children(pid) { return liveCols().filter(function (c) { return (c.parentId || null) === (pid || null); }).sort(byOrder); }
  function collection(id) { var c = DB.get('collections', id); return c && !c.deletedAt ? c : null; }
  function descendantIds(id) {
    var out = [];
    DB.all('collections').forEach(function (c) { if (c.parentId === id && !c.deletedAt) { out.push(c.id); out = out.concat(descendantIds(c.id)); } });
    return out;
  }
  function pathOf(id) {
    var names = [], c = DB.get('collections', id), guard = 0;
    while (c && guard++ < 20) { names.unshift(c.name); c = c.parentId ? DB.get('collections', c.parentId) : null; }
    return names.join(' / ');
  }
  function liveItems() { return DB.all('items').filter(function (i) { return !i.deletedAt; }); }
  function itemsIn(cid) {
    var ids = {};
    DB.all('links').forEach(function (l) { if (l.collectionId === cid) ids[l.itemId] = 1; });
    return liveItems().filter(function (i) { return ids[i.id] && !i.archived; }).sort(function (a, b) { return b.createdAt - a.createdAt; });
  }
  function collectionsOf(itemId) {
    var out = [];
    DB.all('links').forEach(function (l) { if (l.itemId === itemId) { var c = collection(l.collectionId); if (c) out.push(c); } });
    return out;
  }
  function platform(id) { return DB.get('platforms', id); }
  function platformFor(url) {
    var host = '';
    try { host = new URL(url).hostname.replace(/^www\./, '').toLowerCase(); } catch (e) { return 'web'; }
    var list = DB.all('platforms');
    for (var i = 0; i < list.length; i++) {
      var d = list[i].domains || [];
      for (var j = 0; j < d.length; j++) {
        var dom = String(d[j]).toLowerCase();
        if (host === dom || host.slice(-(dom.length + 1)) === '.' + dom) return list[i].id;
      }
    }
    return 'web';
  }
  function normalizeUrl(input) {
    var s = String(input || '').trim();
    if (!s) return null;
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = 'https://' + s;
    try {
      var u = new URL(s);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
      if (u.hostname.indexOf('.') < 0) return null;
      return u.href;
    } catch (e) { return null; }
  }
  function domainOf(url) { try { return new URL(url).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }
  function parseTags(s) {
    var seen = {}, out = [];
    String(s || '').split(/[,\n]/).forEach(function (t) {
      t = t.trim().replace(/^#/, '');
      if (t && !seen[t.toLowerCase()]) { seen[t.toLowerCase()] = 1; out.push(t); }
    });
    return out;
  }
  function failSave(e) { toast('Could not save. Please try again.'); if (window.console) console.error(e); }

  /* collections */
  function saveCollection(data, id) {
    var c = id ? DB.get('collections', id) : null;
    if (c) {
      c.name = data.name; c.color = data.color; c.icon = data.icon; c.parentId = data.parentId || null; c.updatedAt = now();
    } else {
      c = { id: uid(), name: data.name, color: data.color, icon: data.icon, parentId: data.parentId || null, cover: null,
        order: children(data.parentId || null).length, createdAt: now(), updatedAt: now(), deletedAt: null };
    }
    DB.put('collections', c).catch(failSave);
    return c;
  }
  function deleteCollection(id) {
    var ids = [id].concat(descendantIds(id)), t = now();
    ids.forEach(function (cid) {
      var c = DB.get('collections', cid);
      c.deletedAt = t; c.deletedBy = id; c.updatedAt = t;
      DB.put('collections', c).catch(failSave);
    });
  }
  function restoreCollection(id) {
    DB.all('collections').filter(function (c) { return c.deletedBy === id; }).forEach(function (c) {
      c.deletedAt = null; c.deletedBy = null; c.updatedAt = now();
      if (c.id === id && c.parentId) {
        var p = DB.get('collections', c.parentId);
        if (!p || p.deletedAt) c.parentId = null;
      }
      DB.put('collections', c).catch(failSave);
    });
  }
  function purgeCollection(id) {
    var group = DB.all('collections').filter(function (c) { return c.deletedBy === id; }).map(function (c) { return c.id; });
    var set = {}; group.forEach(function (g) { set[g] = 1; });
    DB.all('links').slice().forEach(function (l) { if (set[l.collectionId]) DB.remove('links', l.id); });
    group.forEach(function (g) { DB.remove('collections', g); });
  }

  /* items */
  function setItemCollections(itemId, ids) {
    var want = {}; ids.forEach(function (i) { want[i] = 1; });
    var have = {};
    DB.all('links').slice().forEach(function (l) {
      if (l.itemId !== itemId) return;
      if (!want[l.collectionId]) DB.remove('links', l.id); else have[l.collectionId] = 1;
    });
    ids.forEach(function (cid) {
      if (!have[cid]) DB.put('links', { id: itemId + ':' + cid, itemId: itemId, collectionId: cid, addedAt: now() }).catch(failSave);
    });
  }
  function createItem(data, collectionIds) {
    var t = now();
    var item = { id: uid(), type: data.type, title: data.title, url: data.url || '', domain: data.url ? domainOf(data.url) : '',
      notes: data.notes || '', tags: data.tags || [], thumb: data.thumb || '', platformId: data.url ? (data.platformId || platformFor(data.url)) : (data.platformId || null),
      fileId: data.fileId || '', fileName: data.fileName || '', mime: data.mime || '', size: data.size || 0, kind: data.kind || '',
      favorite: false, archived: false, createdAt: t, updatedAt: t, lastOpenedAt: null, deletedAt: null };
    DB.put('items', item).catch(failSave);
    setItemCollections(item.id, collectionIds);
    return item;
  }
  function touchItem(item) { item.updatedAt = now(); DB.put('items', item).catch(failSave); }
  function purgeItem(id) {
    var gone = DB.get('items', id);
    if (gone && gone.fileId) DB.removeFile(gone.fileId);
    DB.all('links').slice().forEach(function (l) { if (l.itemId === id) DB.remove('links', l.id); });
    DB.remove('items', id);
  }
  function dupKey(url) {
    try {
      var u = new URL(url);
      return u.hostname.replace(/^www\./, '').toLowerCase() + u.pathname.replace(/\/+$/, '') + u.search;
    } catch (e) { return url; }
  }
  function findDuplicate(url, exceptId) {
    var k = dupKey(url);
    return liveItems().filter(function (i) { return i.url && i.id !== exceptId && dupKey(i.url) === k; })[0] || null;
  }
  function purgeOld() {
    var limit = now() - 30 * DAY;
    DB.all('items').slice().forEach(function (i) { if (i.deletedAt && i.deletedAt < limit) purgeItem(i.id); });
    DB.all('collections').filter(function (c) { return c.deletedAt && c.deletedBy === c.id && c.deletedAt < limit; })
      .forEach(function (c) { purgeCollection(c.id); });
  }


  /* ---------- link previews (title and thumbnail) ---------- */
  function youtubeId(url) {
    var m = String(url).match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/|v\/))([A-Za-z0-9_-]{11})/);
    return m ? m[1] : null;
  }
  function decodeHtml(s) {
    return String(s || '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&#x27;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');
  }
  function metaMap(html) {
    var map = {}, tags = html.match(/<meta\s[^>]*>/gi) || [];
    tags.forEach(function (t) {
      var k = t.match(/(?:property|name)\s*=\s*["']([^"']+)["']/i);
      var c = t.match(/content\s*=\s*["']([^"']*)["']/i);
      if (k && c && !map[k[1].toLowerCase()]) map[k[1].toLowerCase()] = decodeHtml(c[1]);
    });
    var tt = html.match(/<title[^>]*>([^<]*)<\/title>/i);
    if (tt) map._title = decodeHtml(tt[1].trim());
    return map;
  }
  function getJson(url) { return fetch(url).then(function (r) { if (!r.ok) throw new Error('http'); return r.json(); }); }
  function getText(url) { return fetch(url, { headers: { 'Accept': 'text/html' } }).then(function (r) { if (!r.ok) throw new Error('http'); return r.text(); }); }

  function junkTitle(t) {
    t = String(t || '').trim();
    return /^(facebook|instagram|tiktok)(\s*[-|].*)?$/i.test(t) || /log in|log into|login|sign up/i.test(t);
  }
  function junkImg(u) {
    return /rsrc\.php|static\.cdninstagram\.com\/rsrc|\/static\/images\/|favicon|\blogo\b/i.test(String(u || ''));
  }
  function fetchPreview(url) {
    var yt = youtubeId(url), host = domainOf(url), work;
    if (yt) {
      var fallback = 'https://i.ytimg.com/vi/' + yt + '/hqdefault.jpg';
      work = getJson('https://www.youtube.com/oembed?format=json&url=' + encodeURIComponent(url))
        .then(function (j) { return { title: j.title || '', thumb: j.thumbnail_url || fallback }; })
        .catch(function () { return { title: '', thumb: fallback }; });
    } else if (/(^|\.)tiktok\.com$/.test(host)) {
      work = getJson('https://www.tiktok.com/oembed?url=' + encodeURIComponent(url))
        .then(function (j) { return { title: j.title || '', thumb: j.thumbnail_url || '' }; });
    } else {
      work = getText(url).then(function (html) {
        var m = metaMap(html.slice(0, 300000)), img = m['og:image'] || m['twitter:image'] || '';
        if (img) { try { img = new URL(img, url).href; } catch (e) { img = ''; } }
        return { title: m['og:title'] || m['twitter:title'] || m._title || '', thumb: img };
      });
    }
    var timeout = new Promise(function (res) { setTimeout(function () { res(null); }, 10000); });
    return Promise.race([work, timeout]).then(function (p) {
      if (!p) return null;
      var title = junkTitle(p.title) ? '' : p.title, thumb = junkImg(p.thumb) ? '' : p.thumb;
      return title || thumb ? { title: title, thumb: thumb } : null;
    }).catch(function () { return null; });
  }
  function applyPreview(item, p) {
    if (!p) return false;
    var changed = false;
    if (p.thumb && item.thumb !== p.thumb) { item.thumb = p.thumb; changed = true; }
    if (p.title && (!item.title || item.title === item.domain || item.title === item.url)) { item.title = p.title.slice(0, 140); changed = true; }
    if (changed) touchItem(item);
    return changed;
  }
  function rerenderSoon() { if (route()[0] !== 'search') render(); }

  /* ---------- smart routing rules (rules first, then source platform) ---------- */
  function rules() { return DB.all('rules').slice().sort(function (a, b) { return a.createdAt - b.createdAt; }); }
  function ruleTarget(url) {
    var host = domainOf(url), pid = platformFor(url), list = rules();
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      var ok = r.type === 'domain' ? (host === r.value || host.slice(-(r.value.length + 1)) === '.' + r.value) : pid === r.value;
      if (ok && collection(r.collectionId)) return { collectionId: r.collectionId, rule: r };
    }
    return null;
  }
  function ruleLabel(r) {
    var c = collection(r.collectionId), pf = r.type === 'platform' ? platform(r.value) : null;
    return (r.type === 'domain' ? r.value : (pf ? pf.name : r.value)) + '  \u2192  ' + (c ? pathOf(c.id) : '(collection deleted)');
  }

  /* ---------- receiving shares from other apps ---------- */
  function firstUrl(t) {
    var m = String(t || '').match(/https?:\/\/[^\s<>"']+/i);
    return m ? m[0].replace(/[)\].,;!?]+$/, '') : null;
  }
  function fileFromPath(f) {
    var C = window.Capacitor;
    if (!C || !C.convertFileSrc) return Promise.reject(new Error('no bridge'));
    return fetch(C.convertFileSrc('file://' + f.path)).then(function (r) { return r.blob(); })
      .then(function (b) { return new File([b], f.name, { type: f.mime || b.type }); });
  }
  function handleShared(d) {
    if (d.files && d.files.length) {
      var usable = d.files.filter(function (f) { return f.size <= MAX_FILE; });
      if (!usable.length) { toast('Files over 200 MB are not supported'); return; }
      toast('Reading shared files...');
      Promise.all(usable.map(fileFromPath)).then(function (list) { openFilesModal(list); })
        .catch(function () { toast('Could not read the shared file'); });
      return;
    }
    var text = String(d.text || '').trim(), url = firstUrl(text);
    if (url) {
      var rest = text.replace(url, '').replace(/\s+/g, ' ').trim();
      if (!rest && d.subject) rest = String(d.subject);
      openItemForm('link', null, '', { url: normalizeUrl(url) || url, title: rest.slice(0, 140), review: true });
    } else if (text) {
      openItemForm('note', null, '', { title: d.subject ? String(d.subject).slice(0, 140) : '', notes: text, review: true });
    }
  }
  function checkShare() {
    var pl = null;
    try { pl = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.NexoraShare; } catch (e) { pl = null; }
    if (!pl || !pl.getPending) return;
    pl.getPending().then(function (r) {
      if (!r || !r.value) return;
      var d; try { d = JSON.parse(r.value); } catch (e) { return; }
      handleShared(d);
    }).catch(function () { /* not running inside the app */ });
  }
  window.nexoraShareArrived = checkShare;


  /* ---------- files: photos, PDFs, documents, videos ---------- */
  var MAX_FILE = 200 * 1024 * 1024;
  var KIND_LABEL = { image: 'Image', video: 'Video', audio: 'Audio', pdf: 'PDF', doc: 'Document', zip: 'Archive', other: 'File' };
  var KIND_ICON = { image: 'image', video: 'video', audio: 'video', pdf: 'file', doc: 'file', zip: 'archive', other: 'file' };
  var KIND_COLOR = { image: '62,160,120', video: '196,76,108', audio: '150,120,170', pdf: '210,118,74', doc: '110,140,190', zip: '212,168,60', other: '130,160,140' };
  var pendingFiles = [], blobUrls = [];
  var pickMode = 'files', coverFor = '', importPending = null;

  function fmtSize(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1048576) return Math.round(n / 1024) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(1) + ' MB';
    return (n / 1073741824).toFixed(2) + ' GB';
  }
  function fileKind(mime, name) {
    mime = mime || '';
    var ext = (String(name).split('.').pop() || '').toLowerCase();
    if (/^image\//.test(mime)) return 'image';
    if (/^video\//.test(mime)) return 'video';
    if (/^audio\//.test(mime)) return 'audio';
    if (mime === 'application/pdf' || ext === 'pdf') return 'pdf';
    if (/^(doc|docx|xls|xlsx|ppt|pptx|txt|csv|rtf|odt)$/.test(ext)) return 'doc';
    if (ext === 'zip' || /zip/.test(mime)) return 'zip';
    return 'other';
  }
  function makeThumb(file, maxSide) {
    return new Promise(function (resolve) {
      var isVideo = /^video\//.test(file.type), isImage = /^image\//.test(file.type);
      if (!isImage && !isVideo) { resolve(''); return; }
      var url = URL.createObjectURL(file), node = isVideo ? document.createElement('video') : new Image(), done = false, tm;
      function finish(out) {
        if (done) return;
        done = true; clearTimeout(tm); URL.revokeObjectURL(url); resolve(out || '');
      }
      function draw(w, h) {
        var k = Math.min(1, (maxSide || 240) / Math.max(w, h)), c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(h * k));
        try { c.getContext('2d').drawImage(node, 0, 0, c.width, c.height); finish(c.toDataURL('image/jpeg', 0.7)); } catch (e) { finish(''); }
      }
      tm = setTimeout(function () { finish(''); }, isVideo ? 8000 : 15000);
      if (isVideo) {
        node.muted = true; node.preload = 'auto'; node.playsInline = true;
        node.onloadeddata = function () {
          try { node.currentTime = isFinite(node.duration) && node.duration > 2 ? Math.min(1, node.duration / 3) : 0.1; } catch (e) { finish(''); }
        };
        node.onseeked = function () { if (node.videoWidth) draw(node.videoWidth, node.videoHeight); else finish(''); };
        node.onerror = function () { finish(''); };
        node.src = url;
      } else {
        node.onload = function () { draw(node.naturalWidth, node.naturalHeight); };
        node.onerror = function () { finish(''); };
        node.src = url;
      }
    });
  }
  function saveFiles(files, cols) {
    closeModal();
    var i = 0, ok = 0, note = '';
    function next() {
      if (i >= files.length) {
        render();
        toast(ok + (ok === 1 ? ' file saved' : ' files saved') + (note ? '. ' + note : ''));
        return;
      }
      var f = files[i++];
      toast('Saving ' + i + ' of ' + files.length + '...');
      if (f.size > MAX_FILE) { note = 'Files over 200 MB were skipped'; next(); return; }
      var id = uid();
      makeThumb(f).then(function (th) {
        return DB.putFile({ id: id, name: f.name, type: f.type, size: f.size, blob: f, createdAt: now() }).then(function () {
          createItem({ type: 'file', title: f.name.replace(/\.[^.]+$/, '') || f.name, thumb: th, platformId: 'docs', fileId: id,
            fileName: f.name, mime: f.type, size: f.size, kind: fileKind(f.type, f.name) }, cols);
          ok++;
        });
      }).catch(function () { note = 'Some files could not be saved (is the phone storage full?)'; }).then(next);
    }
    next();
  }
  function openFilesModal(files) {
    pendingFiles = files;
    var names = files.slice(0, 5).map(function (f) { return '<div class="irow"><span class="grow"><b>' + esc(f.name) + '</b><small>' + fmtSize(f.size) + '</small></span></div>'; }).join('');
    var more = files.length > 5 ? '<p class="note-hint">and ' + (files.length - 5) + ' more</p>' : '';
    openModal('<h2>Save ' + files.length + (files.length === 1 ? ' file' : ' files') + '</h2>' + names + more +
      '<div class="field"><span>Save to</span></div>' + pickChips(currentCollectionId() ? [currentCollectionId()] : []) +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-files">Save</button></div>');
  }
  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result).split(',')[1]); };
      r.onerror = reject;
      r.readAsDataURL(blob);
    });
  }
  function openWith(id) {
    var it = DB.get('items', id), P = null;
    try { P = window.Capacitor && window.Capacitor.Plugins; } catch (e) { P = null; }
    if (!P || !P.Filesystem || !P.Share) { toast('Opening with another app works in the installed app'); return; }
    toast('Preparing file...');
    DB.getFile(it.fileId).then(function (rec) {
      if (!rec) throw new Error('missing');
      return blobToBase64(rec.blob).then(function (b64) {
        return P.Filesystem.writeFile({ path: 'open/' + rec.name.replace(/[^\w.\- ]+/g, '_'), data: b64, directory: 'CACHE', recursive: true });
      });
    }).then(function (r) { return P.Share.share({ title: it.title, files: [r.uri] }); })
      .catch(function () { toast('Could not open this file'); });
  }
  function loadFilePreview(it) {
    blobUrls.forEach(function (u) { URL.revokeObjectURL(u); });
    blobUrls = [];
    if (!it.fileId || !el('fview')) return;
    DB.getFile(it.fileId).then(function (rec) {
      var box = el('fview');
      if (!box) return;
      if (!rec) { box.innerHTML = '<p class="note-hint">This file is not stored on this phone. It was added on another device, and files are not backed up yet.</p>'; return; }
      var url = URL.createObjectURL(rec.blob), html = '';
      blobUrls.push(url);
      if (it.kind === 'image') html = '<img class="hero" src="' + url + '" alt="">';
      else if (it.kind === 'video') html = '<video class="hero" controls src="' + url + '"></video>';
      else if (it.kind === 'audio') html = '<audio controls src="' + url + '" style="width:100%;margin-bottom:10px"></audio>';
      box.innerHTML = html + '<button class="btn" data-action="open-with" data-value="' + it.id + '">' + ic('external') + 'Open with...</button>' +
        '<p class="url" style="margin-top:10px">' + esc(rec.name) + ', ' + fmtSize(rec.size) + '</p>';
    });
  }
  function storageWord() {
    var files = liveItems().filter(function (i) { return i.fileId; }), total = 0;
    files.forEach(function (i) { total += Number(i.size) || 0; });
    return files.length ? files.length + (files.length === 1 ? ' file, ' : ' files, ') + fmtSize(total) : 'No files';
  }

  /* ---------- UI pieces ---------- */
  var form = { color: '', icon: 'folder' };
  var reviewMeta = null, formCover = false;
  var confirmResolve = null;
  var toastTimer;

  function toast(msg, actions) {
    var t = el('toast');
    t.innerHTML = '';
    var s = document.createElement('span');
    s.textContent = msg;
    t.appendChild(s);
    t.classList.remove('act');
    var list = !actions ? [] : (Array.isArray(actions) ? actions : [actions]);
    list.forEach(function (a) {
      var b = document.createElement('button');
      b.className = 'toast-act';
      b.textContent = a.label;
      b.onclick = function () { t.classList.remove('on'); a.fn(); };
      t.appendChild(b);
    });
    if (list.length) t.classList.add('act');
    t.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('on'); }, list.length ? 6000 : 2200);
  }

  function syncScrim() {
    var on = el('sheet').classList.contains('on') || el('modal').classList.contains('on');
    el('scrim').classList.toggle('on', on);
  }
  function openSheet() { closeModal(); el('sheet').classList.add('on'); el('sheet').setAttribute('aria-hidden', 'false'); syncScrim(); }
  function closeSheet() { el('sheet').classList.remove('on'); el('sheet').setAttribute('aria-hidden', 'true'); syncScrim(); }
  function openModal(html) {
    closeSheet();
    var m = el('modal');
    m.innerHTML = '<div class="grab"></div>' + html;
    m.scrollTop = 0;
    m.classList.add('on');
    m.setAttribute('aria-hidden', 'false');
    syncScrim();
  }
  function closeModal() {
    var m = el('modal');
    m.classList.remove('on');
    m.setAttribute('aria-hidden', 'true');
    if (confirmResolve) { var r = confirmResolve; confirmResolve = null; r(false); }
    syncScrim();
  }
  function closeAll() { closeSheet(); closeModal(); }

  function confirmBox(title, text, label) {
    return new Promise(function (resolve) {
      openModal('<h2>' + esc(title) + '</h2><p class="note-hint">' + esc(text) + '</p>' +
        '<div class="actions"><button class="btn ghost" data-action="confirm-no">Cancel</button>' +
        '<button class="btn" data-action="confirm-yes">' + esc(label) + '</button></div>');
      confirmResolve = resolve;
    });
  }

  function thumbOf(item) {
    if (item.type === 'file') {
      var fk = item.kind || 'other';
      return { c: KIND_COLOR[fk], inner: ic(KIND_ICON[fk]), img: item.thumb || '' };
    }
    var p = item.platformId ? platform(item.platformId) : null;
    return {
      c: p ? p.color : '150,120,170',
      inner: item.type === 'note' ? ic('note') : (p ? esc(p.name.charAt(0)) : ic('link')),
      img: item.thumb || ''
    };
  }
  function imgTag(src) {
    return src ? '<img src="' + esc(src) + '" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">' : '';
  }
  function metaOf(item) {
    if (item.type === 'file') return (KIND_LABEL[item.kind || 'other']) + ', ' + fmtSize(item.size) + ', ' + fmtDate(item.createdAt);
    return (item.type === 'note' ? 'Note' : (item.domain || 'Link')) + ', ' + fmtDate(item.createdAt);
  }
  function itemRow(item) {
    var t = thumbOf(item);
    return '<button class="irow" data-action="open-item" data-value="' + item.id + '">' +
      '<span class="thumb" style="--c:' + t.c + '">' + t.inner + imgTag(t.img) + '</span>' +
      '<span class="grow"><b>' + esc(item.title) + '</b><small>' + esc(metaOf(item)) + '</small></span>' +
      (item.favorite ? '<span class="star">' + ic('star') + '</span>' : '') + '</button>';
  }
  function itemCard(item, wide) {
    var t = thumbOf(item);
    return '<button class="icard' + (wide ? ' wide' : '') + '" data-action="open-item" data-value="' + item.id + '">' +
      '<span class="cover" style="--c:' + t.c + '">' + t.inner + imgTag(t.img) + '</span>' +
      '<b>' + esc(item.title) + '</b><small>' + esc(metaOf(item)) + '</small></button>';
  }
  function renderItems(list) {
    if (state.view === 'list') return list.map(itemRow).join('');
    var wideEvery = state.view === 'mixed';
    return '<div class="igrid">' + list.map(function (it, i) { return itemCard(it, wideEvery && i % 5 === 0); }).join('') + '</div>';
  }
  function emptyCard(icon, title, text) {
    return '<div class="empty center">' + ic(icon) + '<h3>' + esc(title) + '</h3><p>' + esc(text) + '</p></div>';
  }
  function colCard(c, wide) {
    var n = itemsIn(c.id).length, s = children(c.id).length;
    return '<button class="col' + (wide ? ' wide' : '') + '" style="--c:' + c.color + '" data-action="go" data-value="collection/' + c.id + '">' +
      ic(c.icon || 'folder') + '<span><h3>' + esc(c.name) + '</h3><small>' + n + (n === 1 ? ' item' : ' items') + '</small>' +
      (s ? '<small>' + s + (s === 1 ? ' subfolder' : ' subfolders') + '</small>' : '') + '</span></button>';
  }
  function byNew(a, b) { return b.createdAt - a.createdAt; }
  function missing() {
    return '<button class="back" data-action="back">' + ic('back') + 'Back</button>' + emptyCard('info', 'Not found', 'This item may have been moved to Trash.');
  }

  /* ---------- views ---------- */
  function viewHome() {
    var roots = children(null);
    var cols = roots.length
      ? '<div class="cols">' + roots.map(function (c, i) { return colCard(c, i === 0); }).join('') + '</div>'
      : '<div class="empty"><h3>Create your first collection</h3><p>Collections are your own folders, like Study or Business. One link can live in several of them.</p>' +
        '<div class="actions"><button class="btn" data-action="new-collection" data-value="">New collection</button>' +
        '<button class="btn ghost" data-action="starter">Add starters</button></div></div>';
    var live = liveItems().filter(function (i) { return !i.archived; }).sort(byNew);
    var recent = live.slice(0, 4);
    var favs = live.filter(function (i) { return i.favorite; }).slice(0, 4);
    return '' +
      '<header class="top"><div class="brand"><img class="mark" src="img/logo.png" alt="">NEXORA</div></header>' +
      '<h1 class="display">Your library</h1>' +
      '<p class="lede">Everything you save, in one place.</p>' +
      '<button class="search" data-action="go" data-value="search">' + ic('search') + '<span>Search links, files and notes</span></button>' +
      '<div class="chips">' +
        '<button class="chip" data-action="add-link" data-value="">' + ic('link') + 'Add link</button>' +
        '<button class="chip" data-action="add-note" data-value="">' + ic('note') + 'New note</button>' +
        '<button class="chip" data-action="pick-file" data-value="*/*">' + ic('upload') + 'Import file</button>' +
      '</div>' +
      (!NexoraSync.signedIn() && DB.all('items').length ? '<button class="empty flat" style="width:100%;margin-top:16px;text-align:left" data-action="go" data-value="settings/account"><p><b>Your library is only on this phone.</b> Tap to sign in and back it up.</p></button>' : '') +
      '<div class="sec-head"><h2>Collections</h2><button class="link" data-action="new-collection" data-value="">New collection</button></div>' +
      cols +
      '<div class="sec-head"><h2>Recently added</h2></div>' +
      (recent.length ? recent.map(itemRow).join('') :
        '<div class="empty"><h3>Nothing saved yet</h3><p>Tap + to save your first link or note.</p></div>') +
      '<div class="sec-head"><h2>Favorites</h2></div>' +
      (favs.length ? favs.map(itemRow).join('') : '<div class="empty flat"><p>Open an item and tap Favorite to keep it here.</p></div>');
  }

  function viewCollection(id) {
    var c = collection(id);
    if (!c) return missing();
    var subs = children(id), items = itemsIn(id);
    var par = c.parentId ? pathOf(c.parentId) : '';
    return '' +
      '<button class="back" data-action="back">' + ic('back') + 'Back</button>' +
      '<div class="hd"><span class="thumb" style="--c:' + c.color + '">' + ic(c.icon || 'folder') + '</span><h1 class="page">' + esc(c.name) + '</h1></div>' +
      '<p class="crumb">' + (par ? esc(par) + ', ' : '') + items.length + (items.length === 1 ? ' item' : ' items') + '</p>' +
      '<div class="chips">' +
        '<button class="chip" data-action="new-collection" data-value="' + id + '">' + ic('folder') + 'Subfolder</button>' +
        '<button class="chip" data-action="add-link" data-value="' + id + '">' + ic('link') + 'Add link</button>' +
        '<button class="chip" data-action="add-note" data-value="' + id + '">' + ic('note') + 'New note</button>' +
        '<button class="chip" data-action="edit-collection" data-value="' + id + '">' + ic('edit') + 'Edit</button>' +
        '<button class="chip" data-action="delete-collection" data-value="' + id + '">' + ic('trash') + 'Delete</button>' +
      '</div>' +
      (subs.length ? '<div class="sec-head"><h2>Subfolders</h2></div><div class="cols">' + subs.map(function (s) { return colCard(s, false); }).join('') + '</div>' : '') +
      '<div class="sec-head"><h2>Items</h2></div>' +
      (items.length ? renderItems(items) : emptyCard('folder', 'Nothing here yet', 'Add a link or note to this collection.'));
  }

  function viewPlatforms() {
    var tiles = DB.all('platforms').slice().sort(function (a, b) { return a.createdAt - b.createdAt; }).map(function (p) {
      var n = liveItems().filter(function (i) { return i.platformId === p.id; }).length;
      return '<button class="plat" style="--c:' + p.color + '" data-action="go" data-value="platform/' + p.id + '">' +
        '<span class="plat-ic">' + esc(p.name.charAt(0)) + '</span><span><b>' + esc(p.name) + '</b><small>' + n + (n === 1 ? ' item' : ' items') + '</small></span></button>';
    }).join('');
    return '' +
      '<div class="title-row"><h1 class="page">Platforms</h1><p class="lede">Where your content came from.</p></div>' +
      '<div class="plats">' + tiles +
        '<button class="plat add" data-action="new-platform"><span class="plat-ic">' + ic('plus') + '</span><span><b>Add platform</b><small>Name and color</small></span></button>' +
      '</div>';
  }

  function viewPlatform(id) {
    var p = platform(id);
    if (!p) return missing();
    var items = liveItems().filter(function (i) { return i.platformId === id && !i.archived; }).sort(byNew);
    return '' +
      '<button class="back" data-action="back">' + ic('back') + 'Platforms</button>' +
      '<div class="hd"><span class="thumb" style="--c:' + p.color + '">' + esc(p.name.charAt(0)) + '</span><h1 class="page">' + esc(p.name) + '</h1></div>' +
      '<p class="crumb">' + items.length + (items.length === 1 ? ' item' : ' items') + '</p>' +
      (items.length ? renderItems(items) : emptyCard('link', 'Inbox is empty', 'Links from ' + p.name + ' will collect here.'));
  }

  var FILTERS = [
    { id: 'all', label: 'All', icon: 'folder', title: 'No items yet', text: 'Items you save will appear here.' },
    { id: 'fav', label: 'Favorites', icon: 'star', title: 'No favorites yet', text: 'Open an item and tap Favorite.' },
    { id: 'recent', label: 'Recent', icon: 'clock', title: 'Nothing opened recently', text: 'Items you open will show up here.' },
    { id: 'archive', label: 'Archived', icon: 'archive', title: 'Archive is empty', text: 'Move items you rarely use here.' },
    { id: 'trash', label: 'Trash', icon: 'trash', title: 'Trash is empty', text: 'Deleted items stay here for 30 days.' }
  ];
  var VIEWS = [
    { id: 'grid', icon: 'grid', label: 'Grid view' },
    { id: 'list', icon: 'list', label: 'List view' },
    { id: 'mixed', icon: 'mixed', label: 'Mixed view' }
  ];

  var KIND_FILTERS = [['all', 'All types'], ['link', 'Links'], ['note', 'Notes'], ['image', 'Images'], ['video', 'Videos'], ['pdf', 'PDFs'], ['doc', 'Documents'], ['audio', 'Audio']];
  var SORTS = [['new', 'Newest first'], ['old', 'Oldest first'], ['az', 'A to Z'], ['size', 'Largest first'], ['viewed', 'Recently opened']];
  function matchesKind(i, k) {
    if (k === 'all') return true;
    if (k === 'link') return i.type === 'link';
    if (k === 'note') return i.type === 'note';
    if (i.type !== 'file') return false;
    if (k === 'doc') return i.kind === 'doc' || i.kind === 'zip' || i.kind === 'other';
    return i.kind === k;
  }
  function sortItems(list) {
    var f = list.slice(), m = state.sort;
    if (m === 'old') f.sort(function (a, b) { return a.createdAt - b.createdAt; });
    else if (m === 'az') f.sort(function (a, b) { return String(a.title).localeCompare(String(b.title)); });
    else if (m === 'size') f.sort(function (a, b) { return (b.size || 0) - (a.size || 0); });
    else if (m === 'viewed') f.sort(function (a, b) { return (b.lastOpenedAt || 0) - (a.lastOpenedAt || 0); });
    else f.sort(byNew);
    return f;
  }
  function savedList(f) {
    var l = liveItems();
    if (f === 'fav') return l.filter(function (i) { return i.favorite && !i.archived; }).sort(byNew);
    if (f === 'recent') return l.filter(function (i) { return i.lastOpenedAt; }).sort(function (a, b) { return b.lastOpenedAt - a.lastOpenedAt; }).slice(0, 50);
    if (f === 'archive') return l.filter(function (i) { return i.archived; }).sort(byNew);
    return l.filter(function (i) { return !i.archived; }).sort(byNew);
  }

  function trashHTML() {
    var items = DB.all('items').filter(function (i) { return i.deletedAt; }).sort(function (a, b) { return b.deletedAt - a.deletedAt; });
    var cols = DB.all('collections').filter(function (c) { return c.deletedAt && c.deletedBy === c.id; });
    if (!items.length && !cols.length) return emptyCard('trash', 'Trash is empty', 'Deleted items stay here for 30 days.');
    function actions(kind, id) {
      return '<button class="mini" data-action="restore" data-value="' + kind + ':' + id + '">Restore</button>' +
        '<button class="mini danger" data-action="purge" data-value="' + kind + ':' + id + '">Delete</button>';
    }
    return '<p class="note-hint">Items are removed for good after 30 days. Deleting here never touches the original YouTube, Facebook or other post.</p>' +
      cols.map(function (c) {
        return '<div class="irow"><span class="thumb" style="--c:' + c.color + '">' + ic(c.icon || 'folder') + '</span><span class="grow"><b>' + esc(c.name) +
          '</b><small>Collection, ' + daysLeft(c.deletedAt) + ' days left</small></span>' + actions('col', c.id) + '</div>';
      }).join('') +
      items.map(function (i) {
        var t = thumbOf(i);
        return '<div class="irow"><span class="thumb" style="--c:' + t.c + '">' + t.inner + '</span><span class="grow"><b>' + esc(i.title) +
          '</b><small>' + daysLeft(i.deletedAt) + ' days left</small></span>' + actions('item', i.id) + '</div>';
      }).join('');
  }

  function viewSaved() {
    var cur = FILTERS.filter(function (f) { return f.id === state.filter; })[0] || FILTERS[0];
    var seg = FILTERS.map(function (f) {
      return '<button data-action="filter" data-value="' + f.id + '" aria-pressed="' + (f.id === state.filter) + '">' + f.label + '</button>';
    }).join('');
    var views = VIEWS.map(function (v) {
      return '<button data-action="view" data-value="' + v.id + '" aria-label="' + v.label + '" aria-pressed="' + (v.id === state.view) + '">' + ic(v.icon) + '</button>';
    }).join('');
    var kinds = KIND_FILTERS.map(function (k) {
      return '<button data-action="kind" data-value="' + k[0] + '" aria-pressed="' + (k[0] === state.kind) + '">' + k[1] + '</button>';
    }).join('');
    var sorts = SORTS.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === state.sort ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('');
    var body;
    if (cur.id === 'trash') body = trashHTML();
    else {
      var list = savedList(cur.id).filter(function (i) { return matchesKind(i, state.kind); });
      if (cur.id !== 'recent') list = sortItems(list);
      body = list.length ? renderItems(list) : emptyCard(cur.icon, cur.title, cur.text);
    }
    return '<div class="title-row"><h1 class="page">Saved</h1></div><div class="seg">' + seg + '</div>' +
      (cur.id === 'trash' ? '' : '<div class="seg">' + kinds + '</div><div class="views">' + views + '<select id="sort-sel" class="sortsel" aria-label="Sort">' + sorts + '</select></div>') + body;
  }

  function viewItem(id) {
    var it = DB.get('items', id);
    if (!it || it.deletedAt) return missing();
    var t = thumbOf(it), p = it.platformId ? platform(it.platformId) : null, cols = collectionsOf(id);
    return '' +
      '<button class="back" data-action="back">' + ic('back') + 'Back</button>' +
      '<div class="hd"><span class="thumb" style="--c:' + t.c + '">' + t.inner + '</span><h1 class="page" style="font-size:24px">' + esc(it.title) + '</h1></div>' +
      '<p class="crumb">' + (p ? esc(p.name) + ', ' : '') + 'saved ' + fmtDate(it.createdAt) + '</p>' +
      (it.type === 'file' ? '<div id="fview" class="fview"><p class="note-hint">Loading...</p></div>' : '') +
      (it.thumb && it.type !== 'file' ? '<img class="hero" src="' + esc(it.thumb) + '" alt="" referrerpolicy="no-referrer" onerror="this.remove()">' : '') +
      (it.url ? '<a class="btn" href="' + esc(it.url) + '" target="_blank" rel="noopener" data-action="opened" data-value="' + id + '">' + ic('external') + 'Open original</a><p class="url" style="margin-top:10px">' + esc(it.url) + '</p>' : '') +
      (it.notes ? '<p class="body-text">' + esc(it.notes) + '</p>' : '') +
      ((it.tags || []).length ? '<div class="tags">' + it.tags.map(function (g) { return '<span class="tag">#' + esc(g) + '</span>'; }).join('') + '</div>' : '') +
      '<div class="group-title">In collections</div>' +
      (cols.length ? '<div class="chips" style="flex-wrap:wrap">' + cols.map(function (c) {
        return '<button class="chip" data-action="go" data-value="collection/' + c.id + '">' + ic(c.icon || 'folder') + esc(c.name) + '</button>';
      }).join('') + '</div>' : '<p class="note-hint">Not in any collection yet. Tap Edit to add one.</p>') +
      '<div class="group" style="margin-top:20px">' +
        row('star', it.favorite ? 'Remove from favorites' : 'Add to favorites', '', 'fav', id) +
        (it.url ? row('image', 'Refresh preview', '', 'refresh-preview', id) : '') +
        row('image', 'Change cover image', '', 'pick-cover', id) +
        (it.type === 'file' ? row('edit', 'Rename', '', 'rename-file', id) : row('edit', 'Edit', '', 'edit-item', id)) +
        row('archive', it.archived ? 'Unarchive' : 'Archive', '', 'archive', id) +
        row('trash', 'Move to Trash', '', 'delete-item', id) +
      '</div>';
  }

  function viewSearch() {
    return '<button class="back" data-action="back">' + ic('back') + 'Home</button>' +
      '<input id="sinput" class="sinput" type="search" placeholder="Search links, notes, tags, collections" autocomplete="off">' +
      '<div id="sresults"></div>';
  }
  function runSearch(q) {
    q = q.trim().toLowerCase();
    var out = el('sresults');
    if (!out) return;
    if (!q) { out.innerHTML = '<p class="note-hint">Type to search titles, links, notes, tags and collections.</p>'; return; }
    var items = liveItems().filter(function (i) {
      var p = i.platformId ? platform(i.platformId) : null;
      var hay = [i.title, i.url, i.domain, i.notes, (i.tags || []).join(' '), collectionsOf(i.id).map(function (c) { return c.name; }).join(' '), p ? p.name : ''].join(' ').toLowerCase();
      return hay.indexOf(q) >= 0;
    }).sort(byNew);
    var cols = liveCols().filter(function (c) { return c.name.toLowerCase().indexOf(q) >= 0; });
    if (!items.length && !cols.length) { out.innerHTML = emptyCard('search', 'No results', 'Try another word.'); return; }
    out.innerHTML = cols.map(function (c) {
      return '<button class="irow" data-action="go" data-value="collection/' + c.id + '"><span class="thumb" style="--c:' + c.color + '">' + ic(c.icon || 'folder') + '</span><span class="grow"><b>' + esc(c.name) + '</b><small>Collection</small></span></button>';
    }).join('') + items.map(itemRow).join('');
  }

  function row(icon, label, value, action, msg) {
    return '<button class="row" data-action="' + action + '" data-value="' + esc(msg) + '">' +
      '<span class="row-ic">' + ic(icon) + '</span><span class="row-label">' + label + '</span>' +
      (value ? '<span class="row-val">' + esc(value) + '</span>' : '') + ic('chev').replace('class="ic"', 'class="ic chev"') + '</button>';
  }
  function paletteName() {
    return PALETTES.filter(function (p) { return p.id === state.palette; })[0].name;
  }
  function viewSettings() {
    return '' +
      '<div class="title-row"><h1 class="page">Settings</h1></div>' +
      '<div class="group">' + row('user', 'Account and backup', NexoraSync.signedIn() ? 'Signed in' : 'Signed out', 'go', 'settings/account') + '</div>' +
      '<div class="group">' + row('palette', 'Appearance', state.rotate ? 'Changes each time' : paletteName(), 'go', 'settings/appearance') + '</div>' +
      '<div class="group-title">Protection</div>' +
      '<div class="group">' + row('lock', 'Security and app lock', lockCfg() ? 'On' : 'Off', 'go', 'settings/security') + '</div>' +
      '<div class="group-title">Your data</div>' +
      '<div class="group">' +
        row('cloud', 'Cloud sync', syncWord(), 'go', 'settings/account') +
        row('exportIc', 'Export backup file', '', 'export-data', '') +
        row('upload', 'Import backup file', '', 'import-data', '') +
        row('storage', 'Storage', storageWord(), 'go', 'settings/storage') +
        row('exportIc', 'Import many links', '', 'import-links', '') +
      '</div>' +
      '<div class="group-title">Smart Share</div>' +
      '<div class="group">' +
        row('route', 'Smart routing rules', rules().length ? String(rules().length) : '', 'go', 'settings/rules') +
        row('phone', 'Manage devices', '', 'soon', 'Devices') +
      '</div>' +
      '<div class="group">' + row('info', 'About NEXORA', VERSION, 'soon', 'NEXORA ' + VERSION) + '</div>';
  }


  function viewRules() {
    var list = rules();
    return '<button class="back" data-action="back">' + ic('back') + 'Settings</button>' +
      '<div class="title-row"><h1 class="page">Routing rules</h1></div>' +
      '<p class="note-hint">When you share something into NEXORA, rules run first. If no rule matches, it goes to the inbox of its source platform. You always see a review screen before saving.</p>' +
      (list.length ? '<div class="group">' + list.map(function (r) {
        return '<div class="row"><span class="row-ic">' + ic('route') + '</span><span class="row-label">' + esc(ruleLabel(r)) + '</span>' +
          '<button class="mini danger" data-action="delete-rule" data-value="' + r.id + '">Delete</button></div>';
      }).join('') + '</div>' : emptyCard('route', 'No rules yet', 'Example: everything from TikTok goes to Study.')) +
      '<div class="actions"><button class="btn" data-action="new-rule">New rule</button></div>';
  }


  function agoText(t) {
    if (!t) return 'never';
    var m = Math.floor((now() - t) / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return m + ' min ago';
    var h = Math.floor(m / 60);
    return h < 24 ? h + ' h ago' : Math.floor(h / 24) + ' days ago';
  }
  function syncWord() {
    if (!NexoraSync.signedIn()) return 'Off';
    var x = NexoraSync.state();
    return x.busy ? 'Syncing' : (x.error ? 'Problem' : 'On');
  }
  function viewAccount() {
    var back = '<button class="back" data-action="back">' + ic('back') + 'Settings</button><div class="title-row"><h1 class="page">Account and backup</h1></div>';
    if (!NexoraSync.signedIn()) {
      return back +
        '<p class="note-hint">Sign in to back up your collections, links and notes. On a new phone, sign in with the same account and everything comes back.</p>' +
        '<label class="field"><span>Email</span><input id="a-email" type="email" autocapitalize="none" autocorrect="off" autocomplete="email"></label>' +
        '<label class="field"><span>Password (at least 6 characters)</span><input id="a-pass" type="password" autocomplete="current-password"></label>' +
        '<div class="actions"><button class="btn" data-action="auth-signin">Sign in</button><button class="btn ghost" data-action="auth-signup">Create account</button></div>' +
        '<p style="margin-top:16px"><button class="link" data-action="auth-reset">Forgot password?</button></p>';
    }
    var x = NexoraSync.state();
    var line = x.busy ? 'Syncing now...' : (x.error ? x.error : 'Last backup: ' + agoText(x.lastSync));
    return back +
      '<div class="group"><div class="row"><span class="row-ic">' + ic('user') + '</span><span class="row-label">' + esc(NexoraSync.email()) + '</span></div>' +
      '<div class="row"><span class="row-ic">' + ic('cloud') + '</span><span class="row-label">' + esc(line) + '</span></div>' +
      (x.pending ? '<div class="row"><span class="row-ic">' + ic('clock') + '</span><span class="row-label">' + x.pending + ' changes waiting to upload</span></div>' : '') + '</div>' +
      '<p class="note-hint">Collections, links, notes and rules are backed up. Imported files are not backed up yet.</p>' +
      '<div class="actions"><button class="btn" data-action="sync-now">Sync now</button><button class="btn ghost" data-action="auth-signout">Sign out</button></div>';
  }

  function viewAppearance() {
    var themes = [['system', 'System'], ['light', 'Light'], ['dark', 'Dark']].map(function (t) {
      return '<button data-action="theme" data-value="' + t[0] + '" aria-pressed="' + (t[0] === state.theme) + '">' + t[1] + '</button>';
    }).join('');
    var pals = PALETTES.map(function (p) {
      return '<button class="pal" data-action="palette" data-value="' + p.id + '" aria-pressed="' + (!state.rotate && state.palette === p.id) + '">' +
        '<span class="dots">' + p.dots.map(function (d) { return '<i style="background:' + d + '"></i>'; }).join('') + '</span><b>' + p.name + '</b>' + ic('check') + '</button>';
    }).join('');
    return '' +
      '<button class="back" data-action="back">' + ic('back') + 'Settings</button>' +
      '<div class="title-row"><h1 class="page">Appearance</h1></div>' +
      '<div class="group-title">Mode</div><div class="seg-big">' + themes + '</div>' +
      '<div class="group-title">Colors</div>' +
      '<div class="group"><div class="row"><span class="row-ic">' + ic('palette') + '</span><span class="row-label">Change colors every time I open the app</span>' +
        '<button class="switch" data-action="rotate" aria-label="Change colors every launch" aria-pressed="' + state.rotate + '"></button></div></div>' +
      '<p class="note-hint">' + (state.rotate ? 'Now showing: ' + paletteName() + '. Tap a color set below to keep it fixed.' : 'Fixed color set. Turn the switch on to change colors on every launch.') + '</p>' +
      '<div class="group">' + pals + '</div>';
  }

  /* ---------- forms ---------- */
  function colorDots(selected, action) {
    return COLORS.map(function (c) {
      return '<button type="button" class="cdot" style="--c:' + c.c + '" aria-label="' + c.name + '" data-action="' + action + '" data-value="' + c.c + '" aria-pressed="' + (c.c === selected) + '"></button>';
    }).join('');
  }

  function openCollectionForm(id, parentId) {
    var c = id ? DB.get('collections', id) : null;
    form.color = c ? c.color : COLORS[liveCols().length % COLORS.length].c;
    form.icon = c ? (c.icon || 'folder') : 'folder';
    var parent = c ? c.parentId : (parentId || null);
    var skip = {};
    if (c) { skip[c.id] = 1; descendantIds(c.id).forEach(function (d) { skip[d] = 1; }); }
    var opts = '<option value="">Top level</option>' + liveCols().filter(function (x) { return !skip[x.id]; })
      .map(function (x) { return { id: x.id, path: pathOf(x.id) }; })
      .sort(function (a, b) { return a.path.localeCompare(b.path); })
      .map(function (x) { return '<option value="' + x.id + '"' + (x.id === parent ? ' selected' : '') + '>' + esc(x.path) + '</option>'; }).join('');
    var icons = FOLDER_ICONS.map(function (n) {
      return '<button type="button" class="icopt" aria-label="' + n + '" data-action="pick-icon" data-value="' + n + '" aria-pressed="' + (n === form.icon) + '">' + ic(n) + '</button>';
    }).join('');
    openModal('<h2>' + (c ? 'Edit collection' : (parent ? 'New subfolder' : 'New collection')) + '</h2>' +
      '<label class="field"><span>Name</span><input id="f-name" type="text" maxlength="60" placeholder="e.g. Study" value="' + esc(c ? c.name : '') + '"></label>' +
      '<div class="field"><span>Color</span><div class="colors" id="f-colors">' + colorDots(form.color, 'pick-color') + '</div></div>' +
      '<div class="field"><span>Icon</span><div class="icons" id="f-icons">' + icons + '</div></div>' +
      '<label class="field"><span>Inside</span><select id="f-parent">' + opts + '</select></label>' +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-collection" data-value="' + (id || '') + '">Save</button></div>');
  }

  function saveCollectionForm(id) {
    var name = el('f-name').value.trim();
    if (!name) { toast('Give the collection a name'); return; }
    var c = saveCollection({ name: name, color: form.color, icon: form.icon, parentId: el('f-parent').value || null }, id || null);
    closeModal();
    render();
    toast(id ? 'Collection updated' : '"' + c.name + '" created');
  }

  function openPlatformForm() {
    form.color = COLORS[DB.all('platforms').length % COLORS.length].c;
    openModal('<h2>New platform</h2>' +
      '<label class="field"><span>Name</span><input id="f-pname" type="text" maxlength="40" placeholder="e.g. Pinterest"></label>' +
      '<label class="field"><span>Website domain (optional)</span><input id="f-pdomain" type="text" autocapitalize="none" placeholder="pinterest.com"></label>' +
      '<div class="field"><span>Color</span><div class="colors" id="f-colors">' + colorDots(form.color, 'pick-color') + '</div></div>' +
      '<p class="note-hint">With a domain, links from that site go to this platform automatically.</p>' +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-platform">Save</button></div>');
  }
  function savePlatformForm() {
    var name = el('f-pname').value.trim();
    if (!name) { toast('Give the platform a name'); return; }
    var dom = el('f-pdomain').value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
    DB.put('platforms', { id: uid(), name: name, color: form.color, domains: dom ? [dom] : [], builtin: false, createdAt: now(), updatedAt: now() }).catch(failSave);
    closeModal(); render(); toast('"' + name + '" added');
  }

  function pickChips(selected) {
    var list = liveCols().map(function (c) { return { id: c.id, path: pathOf(c.id) }; })
      .sort(function (a, b) { return a.path.localeCompare(b.path); });
    if (!list.length) return '<p class="note-hint">No collections yet. This will be saved to its platform inbox.</p>';
    return '<div class="picks">' + list.map(function (c) {
      return '<button type="button" class="pick" data-action="toggle-pick" data-value="' + c.id + '" aria-pressed="' + (selected.indexOf(c.id) >= 0) + '">' + esc(c.path) + '</button>';
    }).join('') + '</div>';
  }
  function pickedCols() {
    return Array.prototype.slice.call(document.querySelectorAll('#modal .pick[aria-pressed="true"]')).map(function (b) { return b.getAttribute('data-value'); });
  }

  function platformOptions(selected) {
    return '<option value="">Detect automatically</option>' + DB.all('platforms').slice().sort(function (x, y) { return x.createdAt - y.createdAt; })
      .map(function (p) { return '<option value="' + p.id + '"' + (p.id === selected ? ' selected' : '') + '>' + esc(p.name) + '</option>'; }).join('');
  }

  function openItemForm(kind, item, presetCol, prefill) {
    prefill = prefill || {};
    var isLink = kind === 'link', review = !!prefill.review, hint = '';
    var sel = item ? collectionsOf(item.id).map(function (c) { return c.id; }) : (presetCol ? [presetCol] : []);
    if (review && isLink && !sel.length) {
      var tr = ruleTarget(prefill.url);
      if (tr) { sel = [tr.collectionId]; hint = 'Rule applied: ' + ruleLabel(tr.rule); }
    }
    var url = item ? item.url : (prefill.url || '');
    var title = item ? item.title : (prefill.title || '');
    var notes = item ? item.notes : (prefill.notes || '');
    reviewMeta = null; formCover = false;
    var head = review
      ? '<h2>Save to NEXORA</h2>' + (isLink ? '<div class="irow rv"><span class="thumb" id="rv-img" style="--c:150,120,170">' + ic('link') + '</span><span class="grow"><b id="rv-title">Fetching preview...</b><small>' + esc(domainOf(url)) + '</small></span></div>' : '')
      : '<h2>' + (item ? 'Edit item' : (isLink ? 'Add link' : 'New note')) + '</h2>';
    openModal(head +
      (isLink ? '<label class="field"><span>Link</span><input id="f-url" type="url" autocapitalize="none" autocorrect="off" placeholder="https://" value="' + esc(url) + '"></label>' : '') +
      '<label class="field"><span>Title' + (isLink ? ' (optional)' : '') + '</span><input id="f-title" type="text" maxlength="140" value="' + esc(title) + '"></label>' +
      (isLink && !item ? '<div class="field"><span>Cover image (optional)</span><div class="irow rv" style="margin:0"><span class="thumb" id="cv-thumb" style="--c:150,120,170">' + ic('image') + '</span><span class="grow"><small>No preview? Choose a screenshot of the video.</small></span><button type="button" class="mini" data-action="form-cover">Choose</button></div></div>' : '') +
      (isLink ? '<label class="field"><span>Source platform</span><select id="f-platform">' + platformOptions(item ? item.platformId : (prefill.platformId || '')) + '</select></label>' : '') +
      '<label class="field"><span>' + (isLink ? 'Notes (optional)' : 'Note') + '</span><textarea id="f-notes" class="' + (isLink ? '' : 'tall') + '">' + esc(notes) + '</textarea></label>' +
      '<label class="field"><span>Tags (separate with commas)</span><input id="f-tags" type="text" autocapitalize="none" value="' + esc(item ? (item.tags || []).join(', ') : '') + '"></label>' +
      '<div class="field"><span>Save to</span></div>' + (hint ? '<p class="note-hint">' + esc(hint) + '</p>' : '') + pickChips(sel) +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-item" data-value="' + kind + ':' + (item ? item.id : '') + '">Save</button></div>');

    if (review && isLink) {
      fetchPreview(url).then(function (p) {
        var box = el('rv-title');
        if (!box) return;
        if (!formCover) reviewMeta = p;
        if (!p) { box.textContent = 'No preview available'; return; }
        box.textContent = p.title || domainOf(url);
        if (p.thumb && !formCover) el('rv-img').insertAdjacentHTML('beforeend', imgTag(p.thumb));
        var ti = el('f-title');
        if (ti && !ti.value.trim() && p.title) ti.value = p.title.slice(0, 140);
      });
    }
  }

  function saveItemForm(kind, id) {
    var title = el('f-title').value.trim(), notes = el('f-notes').value.trim(), tags = parseTags(el('f-tags').value), cols = pickedCols();
    var data;
    if (kind === 'link') {
      var url = normalizeUrl(el('f-url').value);
      if (!url) { toast('Enter a valid link, like youtube.com/...'); return; }
      var pf = el('f-platform') ? el('f-platform').value : '';
      data = { type: 'link', title: title || domainOf(url), url: url, notes: notes, tags: tags, platformId: pf || platformFor(url), thumb: reviewMeta && reviewMeta.thumb ? reviewMeta.thumb : '' };
      var dup = findDuplicate(url, id);
      if (dup) {
        confirmBox('Already saved', '"' + dup.title + '" has the same link. Save it again?', 'Save anyway').then(function (ok) { if (ok) commitItem(data, cols, id); });
        return;
      }
    } else {
      if (!title && !notes) { toast('Write a title or some text'); return; }
      data = { type: 'note', title: title || notes.split('\n')[0].slice(0, 60), notes: notes, tags: tags };
    }
    commitItem(data, cols, id);
  }

  function commitItem(data, cols, id) {
    closeModal();
    if (id) {
      var it = DB.get('items', id);
      it.title = data.title; it.notes = data.notes; it.tags = data.tags;
      if (data.url) { it.url = data.url; it.domain = domainOf(data.url); it.platformId = data.platformId || platformFor(data.url); }
      touchItem(it);
      setItemCollections(id, cols);
      render();
      toast('Changes saved');
      return;
    }
    var item = createItem(data, cols);
    render();
    toast('Saved successfully', [
      { label: 'View', fn: function () { location.hash = '#/item/' + item.id; } },
      { label: 'Undo', fn: function () { purgeItem(item.id); render(); } }
    ]);
    if (item.url && !item.thumb) {
      fetchPreview(item.url).then(function (p) { if (applyPreview(item, p)) rerenderSoon(); });
    }
  }

  function openRuleForm() {
    var cols = liveCols().map(function (c) { return { id: c.id, path: pathOf(c.id) }; }).sort(function (a, b) { return a.path.localeCompare(b.path); });
    if (!cols.length) { toast('Create a collection first'); return; }
    var pOpts = DB.all('platforms').slice().sort(function (x, y) { return x.createdAt - y.createdAt; })
      .map(function (p) { return '<option value="' + p.id + '">' + esc(p.name) + '</option>'; }).join('');
    var cOpts = cols.map(function (c) { return '<option value="' + c.id + '">' + esc(c.path) + '</option>'; }).join('');
    openModal('<h2>New rule</h2>' +
      '<label class="field"><span>When the link is from</span><select id="f-rplat">' + pOpts + '</select></label>' +
      '<label class="field"><span>Or a website domain (optional, used instead)</span><input id="f-rdom" type="text" autocapitalize="none" placeholder="example.com"></label>' +
      '<label class="field"><span>Send it to</span><select id="f-rcol">' + cOpts + '</select></label>' +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-rule">Save rule</button></div>');
  }
  function saveRuleForm() {
    var dom = el('f-rdom').value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
    var r = { id: uid(), type: dom ? 'domain' : 'platform', value: dom || el('f-rplat').value, collectionId: el('f-rcol').value, createdAt: now(), updatedAt: now() };
    DB.put('rules', r).catch(failSave);
    closeModal(); render(); toast('Rule added');
  }


  /* ---------- import many links at once ---------- */
  function openBulkForm() {
    openModal('<h2>Import links</h2><p class="note-hint">Paste your links, one per line. Any text that contains links works. Already saved links are skipped.</p>' +
      '<label class="field"><span>Links</span><textarea id="f-bulk" class="tall" placeholder="https://..."></textarea></label>' +
      '<div class="field"><span>Save to</span></div>' + pickChips([]) +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-bulk">Import</button></div>');
  }
  function previewOne(it, done) {
    fetchPreview(it.url).then(function (p) { done(applyPreview(it, p)); });
  }
  function previewQueue(list) {
    var i = 0, running = 0, changed = false;
    function next() {
      while (running < 2 && i < list.length) {
        running++;
        previewOne(list[i++], function (c) {
          if (c) changed = true;
          running--;
          if (i < list.length) next(); else if (!running && changed) rerenderSoon();
        });
      }
    }
    next();
  }
  function saveBulk() {
    var found = (el('f-bulk').value.match(/https?:\/\/[^\s<>"']+/gi) || []).map(function (u) { return u.replace(/[)\].,;!?]+$/, ''); });
    var cols = pickedCols();
    if (!found.length) { toast('No links found in that text'); return; }
    var seen = {}, added = [], skipped = 0;
    found.forEach(function (u) {
      var url = normalizeUrl(u);
      if (!url) return;
      var k = dupKey(url);
      if (seen[k] || findDuplicate(url, null)) { skipped++; return; }
      seen[k] = 1;
      added.push(createItem({ type: 'link', title: domainOf(url), url: url, notes: '', tags: [], platformId: platformFor(url), thumb: '' }, cols));
    });
    closeModal();
    render();
    toast(added.length + (added.length === 1 ? ' link added' : ' links added') + (skipped ? ', ' + skipped + ' skipped (already saved)' : ''));
    previewQueue(added);
  }

  /* ---------- cover image, backup file, storage ---------- */
  function setFormCover(file) {
    if (!file || !/^image\//.test(file.type)) { toast('Pick an image'); return; }
    makeThumb(file, 480).then(function (th) {
      if (!th) { toast('Could not use that image'); return; }
      formCover = true;
      reviewMeta = { title: (reviewMeta && reviewMeta.title) || '', thumb: th };
      if (el('cv-thumb')) el('cv-thumb').innerHTML = imgTag(th);
      if (el('rv-img')) el('rv-img').innerHTML = imgTag(th);
    });
  }
  function setCover(id, file) {
    var it = DB.get('items', id);
    if (!it || !file) return;
    if (!/^image\//.test(file.type)) { toast('Pick an image'); return; }
    makeThumb(file, 480).then(function (th) {
      if (!th) { toast('Could not use that image'); return; }
      it.thumb = th; touchItem(it); render(); toast('Cover image updated');
    });
  }
  function exportData() {
    var data = { app: 'NEXORA', format: 1, exportedAt: now() };
    ['collections', 'items', 'links', 'platforms', 'rules'].forEach(function (k) { data[k] = DB.all(k); });
    var P = window.Capacitor && window.Capacitor.Plugins;
    if (!P || !P.Filesystem || !P.Share) { toast('Export works in the installed app'); return; }
    var name = 'NEXORA-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    toast('Preparing backup...');
    P.Filesystem.writeFile({ path: 'export/' + name, data: JSON.stringify(data), directory: 'CACHE', encoding: 'utf8', recursive: true })
      .then(function (r) { return P.Share.share({ title: name, files: [r.uri] }); })
      .catch(function () { toast('Could not create the backup file'); });
  }
  function readBackup(file) {
    var r = new FileReader();
    r.onload = function () {
      var d;
      try { d = JSON.parse(r.result); } catch (e) { d = null; }
      if (!d || d.app !== 'NEXORA') { toast('This is not a NEXORA backup file'); return; }
      importPending = d;
      var n = function (k) { return (d[k] || []).length; };
      openModal('<h2>Import backup</h2><p class="note-hint">This backup has ' + n('collections') + ' collections, ' + n('items') + ' items and ' + n('rules') +
        ' rules. Newer copies already on this phone are kept. Nothing is deleted. Files (photos, PDFs) are not inside backup files.</p>' +
        '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="import-confirm">Import</button></div>');
    };
    r.onerror = function () { toast('Could not read the file'); };
    r.readAsText(file);
  }
  function importConfirm() {
    var d = importPending, added = 0;
    if (!d) return;
    function t(x) { return x.updatedAt || x.addedAt || x.createdAt || 0; }
    ['collections', 'items', 'links', 'platforms', 'rules'].forEach(function (store2) {
      (d[store2] || []).forEach(function (o) {
        if (!o || !o.id) return;
        var l = DB.get(store2, o.id);
        if (!l || t(o) > t(l)) { DB.put(store2, o).catch(failSave); added++; }
      });
    });
    importPending = null; closeModal(); render(); toast(added + ' records imported');
  }
  function viewStorage() {
    var files = liveItems().filter(function (i) { return i.type === 'file'; }), total = 0, by = {};
    files.forEach(function (i) { total += i.size || 0; by[i.kind] = (by[i.kind] || 0) + (i.size || 0); });
    var big = files.slice().sort(function (a, b) { return (b.size || 0) - (a.size || 0); }).slice(0, 15);
    return '<button class="back" data-action="back">' + ic('back') + 'Settings</button><div class="title-row"><h1 class="page">Storage</h1></div>' +
      '<div class="group"><div class="row"><span class="row-ic">' + ic('storage') + '</span><span class="row-label">' + files.length + ' files on this phone</span><span class="row-val">' + fmtSize(total) + '</span></div>' +
      Object.keys(by).map(function (k) { return '<div class="row"><span class="row-ic">' + ic(KIND_ICON[k] || 'file') + '</span><span class="row-label">' + (KIND_LABEL[k] || k) + '</span><span class="row-val">' + fmtSize(by[k]) + '</span></div>'; }).join('') + '</div>' +
      '<p class="note-hint" id="quota"></p>' +
      '<div class="group-title">Largest files</div>' +
      (big.length ? big.map(function (i) {
        return '<div class="irow"><span class="thumb" style="--c:' + (KIND_COLOR[i.kind] || KIND_COLOR.other) + '">' + ic(KIND_ICON[i.kind] || 'file') + '</span><span class="grow"><b>' + esc(i.title) + '</b><small>' + fmtSize(i.size) + '</small></span>' +
          '<button class="mini danger" data-action="delete-file" data-value="' + i.id + '">Delete</button></div>';
      }).join('') : emptyCard('storage', 'No files yet', 'Photos, PDFs and other files you add will be listed here.'));
  }
  function storageEstimate() {
    if (!navigator.storage || !navigator.storage.estimate) return;
    navigator.storage.estimate().then(function (e) {
      var q = el('quota');
      if (q && e.quota) q.textContent = 'This phone allows NEXORA about ' + fmtSize(e.quota) + '. Used so far: ' + fmtSize(e.usage) + '.';
    });
  }

  /* ---------- router ---------- */
  function route() {
    var h = (location.hash || '#/home').replace(/^#\/?/, '');
    return (h || 'home').split('/');
  }
  function currentCollectionId() {
    var r = route();
    return r[0] === 'collection' && collection(r[1]) ? r[1] : '';
  }

  function render() {
    var r = route(), tab = r[0], html, navTab = tab;
    if (tab === 'collection') { html = viewCollection(r[1]); navTab = 'home'; }
    else if (tab === 'item') { html = viewItem(r[1]); navTab = 'home'; }
    else if (tab === 'search') { html = viewSearch(); navTab = 'home'; }
    else if (tab === 'platform') { html = viewPlatform(r[1]); navTab = 'platforms'; }
    else if (tab === 'settings' && r[1] === 'appearance') html = viewAppearance();
    else if (tab === 'settings' && r[1] === 'rules') html = viewRules();
    else if (tab === 'settings' && r[1] === 'account') html = viewAccount();
    else if (tab === 'settings' && r[1] === 'security') html = viewSecurity();
    else if (tab === 'settings' && r[1] === 'storage') html = viewStorage();
    else if (tab === 'settings') html = viewSettings();
    else if (tab === 'platforms') html = viewPlatforms();
    else if (tab === 'saved') html = viewSaved();
    else { navTab = 'home'; html = viewHome(); }
    el('view').innerHTML = html;
    var items = document.querySelectorAll('.nav-item');
    for (var i = 0; i < items.length; i++) {
      if (items[i].getAttribute('data-tab') === navTab) items[i].setAttribute('aria-current', 'page');
      else items[i].removeAttribute('aria-current');
    }
    if (tab === 'item') { var cur = DB.get('items', r[1]); if (cur && cur.type === 'file') loadFilePreview(cur); }
    if (tab === 'settings' && r[1] === 'storage') storageEstimate();
    if (tab === 'search') { var si = el('sinput'); if (si) { runSearch(''); si.focus(); } }
  }

  /* ---------- add sheet ---------- */
  var ADD_OPTIONS = [
    ['link', 'Add link', 'add-link', ''], ['image', 'Add image', 'pick-file', 'image/*'],
    ['file', 'Add document', 'pick-file', '*/*'],
    ['video', 'Add video', 'pick-file', 'video/*,audio/*'], ['note', 'Create note', 'add-note', ''], ['upload', 'Import file', 'pick-file', '*/*']
  ];
  function buildSheet() {
    el('sheet-items').innerHTML = ADD_OPTIONS.map(function (o) {
      return '<button class="opt" data-action="' + o[2] + '" data-value="' + o[3] + '">' + ic(o[0]) + o[1] + '</button>';
    }).join('');
  }

  /* ---------- actions ---------- */
  function startStarters() {
    var names = ['Study', 'Business', 'Personal', 'Ideas'], icons = ['bookmark', 'folder', 'lock', 'star'];
    names.forEach(function (n, i) { saveCollection({ name: n, color: COLORS[i * 2 % COLORS.length].c, icon: icons[i], parentId: null }, null); });
    render();
    toast('Starter collections added');
  }

  function onAction(a, v) {
    var parts, it, c;
    switch (a) {
      case 'tab': closeAll(); location.replace('#/' + v); break;
      case 'go': location.hash = '#/' + v; break;
      case 'back': history.back(); break;
      case 'add': openSheet(); break;
      case 'close-sheet': closeAll(); break;
      case 'soon': closeAll(); toast(v + ' is coming in the next step'); break;
      case 'theme': state.theme = v; store.set('theme', v); applyTheme(); render(); break;
      case 'palette':
        state.palette = v; state.rotate = false; store.set('palette', v); store.set('rotate', '0'); applyTheme(); render(); break;
      case 'rotate':
        state.rotate = !state.rotate; store.set('rotate', state.rotate ? '1' : '0');
        if (!state.rotate) store.set('palette', state.palette);
        render();
        toast(state.rotate ? 'Colors will change each time you open the app' : 'Colors are now fixed');
        break;
      case 'filter': state.filter = v; render(); break;
      case 'view': state.view = v; store.set('view', v); render(); break;
      case 'new-collection': openCollectionForm(null, v || null); break;
      case 'edit-collection': openCollectionForm(v, null); break;
      case 'save-collection': saveCollectionForm(v); break;
      case 'starter': startStarters(); break;
      case 'pick-color': case 'pick-icon': {
        var box = a === 'pick-color' ? 'f-colors' : 'f-icons';
        if (a === 'pick-color') form.color = v; else form.icon = v;
        Array.prototype.forEach.call(el(box).children, function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-value') === v ? 'true' : 'false'); });
        break;
      }
      case 'toggle-pick': {
        var btn = document.querySelector('#modal .pick[data-value="' + v + '"]');
        if (btn) btn.setAttribute('aria-pressed', btn.getAttribute('aria-pressed') === 'true' ? 'false' : 'true');
        break;
      }
      case 'add-link': openItemForm('link', null, v || currentCollectionId()); break;
      case 'add-note': openItemForm('note', null, v || currentCollectionId()); break;
      case 'edit-item': openItemForm(DB.get('items', v).type, DB.get('items', v), null); break;
      case 'save-item': parts = v.split(':'); saveItemForm(parts[0], parts[1] || null); break;
      case 'new-platform': openPlatformForm(); break;
      case 'new-rule': openRuleForm(); break;
      case 'pin-set': openPinForm('set'); break;
      case 'pin-change': openPinForm('change'); break;
      case 'pin-remove': openPinForm('remove'); break;
      case 'pin-save': savePinForm(v); break;
      case 'lock-key': lockKey(v); break;
      case 'lock-bio': tryBio(); break;
      case 'bio-toggle': {
        var bc = lockCfg();
        if (!bc) break;
        if (bc.bio) { bc.bio = false; store.set('lock', JSON.stringify(bc)); render(); toast('Fingerprint unlock is off'); break; }
        bioAuth().then(function () { bc.bio = true; store.set('lock', JSON.stringify(bc)); render(); toast('Fingerprint unlock is on'); })
          .catch(function () { toast('Fingerprint was not confirmed'); });
        break;
      }
      case 'lock-forgot':
        el('lock-reset').hidden = false;
        el('lock-reset-note').textContent = NexoraSync.signedIn() ? 'Type your NEXORA account password (' + NexoraSync.email() + ') to remove the PIN.' : 'You are not signed in on this phone, so the PIN cannot be reset from here.';
        break;
      case 'lock-reset': lockReset(); break;
      case 'import-links': openBulkForm(); break;
      case 'pick-file': closeAll(); pickMode = 'files'; el('picker').multiple = true; el('picker').accept = v || '*/*'; el('picker').click(); break;
      case 'form-cover': pickMode = 'formcover'; el('picker').multiple = false; el('picker').accept = 'image/*'; el('picker').click(); break;
      case 'pick-cover': pickMode = 'cover'; coverFor = v; el('picker').multiple = false; el('picker').accept = 'image/*'; el('picker').click(); break;
      case 'import-data': closeAll(); pickMode = 'import'; el('picker').multiple = false; el('picker').accept = '*/*'; el('picker').click(); break;
      case 'import-confirm': importConfirm(); break;
      case 'export-data': exportData(); break;
      case 'kind': state.kind = v; render(); break;
      case 'delete-file':
        it = DB.get('items', v); it.deletedAt = now(); touchItem(it); render();
        toast('Moved to Trash', { label: 'Undo', fn: function () { it.deletedAt = null; touchItem(it); render(); } });
        break;
      case 'save-files': saveFiles(pendingFiles, pickedCols()); break;
      case 'open-with': openWith(v); break;
      case 'rename-file': {
        it = DB.get('items', v);
        confirmBox('Rename', 'Change the title shown in NEXORA?', 'Continue').then(function (ok) {
          if (!ok) return;
          openModal('<h2>Rename</h2><label class="field"><span>Title</span><input id="f-rename" type="text" maxlength="140" value="' + esc(it.title) + '"></label>' +
            '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="save-rename" data-value="' + v + '">Save</button></div>');
        });
        break;
      }
      case 'save-rename': it = DB.get('items', v); if (el('f-rename').value.trim()) { it.title = el('f-rename').value.trim(); touchItem(it); } closeModal(); render(); break;
      case 'save-bulk': saveBulk(); break;
      case 'auth-signin': case 'auth-signup': {
        var em = el('a-email').value.trim(), pw = el('a-pass').value;
        if (!em || !pw) { toast('Enter your email and password'); break; }
        toast(a === 'auth-signup' ? 'Creating account...' : 'Signing in...');
        (a === 'auth-signup' ? NexoraSync.signUp(em, pw) : NexoraSync.signIn(em, pw)).then(function () {
          render(); toast('Backup complete. Your library is safe in your account.');
        }).catch(function (e) { toast(e.message); });
        break;
      }
      case 'auth-reset': {
        var em2 = el('a-email').value.trim();
        if (!em2) { toast('Type your email first'); break; }
        NexoraSync.reset(em2).then(function () { toast('Password reset email sent'); }).catch(function (e) { toast(e.message); });
        break;
      }
      case 'sync-now':
        toast('Syncing...');
        NexoraSync.syncNow().then(function () { render(); toast('Backup complete'); }).catch(function (e) { render(); toast(e.message); });
        break;
      case 'auth-signout':
        confirmBox('Sign out?', 'Your data stays on this phone and in your account. Sign in again any time to sync.', 'Sign out').then(function (ok) {
          if (ok) { NexoraSync.signOut(); render(); toast('Signed out'); }
        });
        break;
      case 'save-rule': saveRuleForm(); break;
      case 'delete-rule': DB.remove('rules', v); render(); toast('Rule deleted'); break;
      case 'refresh-preview':
        it = DB.get('items', v); toast('Fetching preview...');
        fetchPreview(it.url).then(function (p) {
          if (!p) { toast('No preview available for this site'); return; }
          applyPreview(it, p); render(); toast('Preview updated');
        });
        break;
      case 'save-platform': savePlatformForm(); break;
      case 'open-item':
        it = DB.get('items', v); it.lastOpenedAt = now(); DB.put('items', it).catch(failSave);
        location.hash = '#/item/' + v; break;
      case 'opened': it = DB.get('items', v); if (it) { it.lastOpenedAt = now(); DB.put('items', it).catch(failSave); } break;
      case 'fav': it = DB.get('items', v); it.favorite = !it.favorite; touchItem(it); render(); toast(it.favorite ? 'Added to favorites' : 'Removed from favorites'); break;
      case 'archive': it = DB.get('items', v); it.archived = !it.archived; touchItem(it); render(); toast(it.archived ? 'Archived' : 'Moved back to your library'); break;
      case 'delete-item':
        it = DB.get('items', v); it.deletedAt = now(); touchItem(it);
        history.back();
        toast('Moved to Trash', { label: 'Undo', fn: function () { it.deletedAt = null; touchItem(it); render(); } });
        break;
      case 'delete-collection':
        c = collection(v);
        confirmBox('Delete "' + c.name + '"?', 'It and its subfolders move to Trash for 30 days. The items inside are not deleted.', 'Move to Trash').then(function (ok) {
          if (!ok) return;
          deleteCollection(v);
          if (currentCollectionId() === v) history.back(); else render();
          toast('Moved to Trash', { label: 'Undo', fn: function () { restoreCollection(v); render(); } });
        });
        break;
      case 'restore':
        parts = v.split(':');
        if (parts[0] === 'col') restoreCollection(parts[1]);
        else { it = DB.get('items', parts[1]); it.deletedAt = null; touchItem(it); }
        render(); toast('Restored'); break;
      case 'purge':
        parts = v.split(':');
        confirmBox('Delete for good?', 'This cannot be undone. Only your NEXORA copy is removed, never the original post or video.', 'Delete').then(function (ok) {
          if (!ok) return;
          if (parts[0] === 'col') purgeCollection(parts[1]); else purgeItem(parts[1]);
          render(); toast('Deleted');
        });
        break;
      case 'confirm-yes': { var r = confirmResolve; confirmResolve = null; closeModal(); if (r) r(true); break; }
      case 'confirm-no': closeModal(); break;
    }
  }

  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-action]') : null;
    if (!t) return;
    onAction(t.getAttribute('data-action'), t.getAttribute('data-value'));
  });
  document.addEventListener('change', function (e) {
    if (e.target && e.target.id === 'lock-timeout') {
      var c = lockCfg();
      if (c) { c.timeout = Number(e.target.value); store.set('lock', JSON.stringify(c)); toast('Saved'); }
      return;
    }
    if (e.target && e.target.id === 'picker') {
      var list = Array.prototype.slice.call(e.target.files || []);
      e.target.value = '';
      if (!list.length) return;
      if (pickMode === 'formcover') setFormCover(list[0]);
      else if (pickMode === 'cover') setCover(coverFor, list[0]);
      else if (pickMode === 'import') readBackup(list[0]);
      else openFilesModal(list);
    }
    if (e.target && e.target.id === 'sort-sel') { state.sort = e.target.value; store.set('sort', state.sort); render(); }
  });
  document.addEventListener('input', function (e) {
    if (e.target && e.target.id === 'sinput') runSearch(e.target.value);
  });
  window.addEventListener('hashchange', function () { closeAll(); render(); window.scrollTo(0, 0); });


  /* ---------- app lock (PIN) ---------- */
  var locked = false, pinBuf = '', failCount = 0, lockedUntil = 0, hiddenAt = 0;
  var TIMEOUTS = [[0, 'Immediately'], [30, 'After 30 seconds'], [60, 'After 1 minute'], [300, 'After 5 minutes']];

  var bioOk = false;
  function bioPlugin() { try { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.NexoraShare; } catch (e) { return null; } }
  function bioAvailable() {
    var pl = bioPlugin();
    if (!pl || !pl.biometricAvailable) return Promise.resolve(false);
    return pl.biometricAvailable().then(function (r) { return !!(r && r.available); }).catch(function () { return false; });
  }
  function bioAuth() {
    var pl = bioPlugin();
    if (!pl || !pl.biometricAuth) return Promise.reject(new Error('not available'));
    return pl.biometricAuth();
  }
  function tryBio() {
    if (!locked) return;
    bioAuth().then(function () { unlock(); }).catch(function () { /* stay on the PIN screen */ });
  }
  function lockCfg() { try { return JSON.parse(store.get('lock', '')) || null; } catch (e) { return null; } }
  function toB64(buf) { var t = '', a = new Uint8Array(buf); for (var i = 0; i < a.length; i++) t += String.fromCharCode(a[i]); return btoa(t); }
  function hashPin(pin, saltB64, iter) {
    var raw = atob(saltB64), salt = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) salt[i] = raw.charCodeAt(i);
    return crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits'])
      .then(function (k) { return crypto.subtle.deriveBits({ name: 'PBKDF2', salt: salt, iterations: iter, hash: 'SHA-256' }, k, 256); })
      .then(toB64);
  }
  function savePin(pin, timeout) {
    var salt = new Uint8Array(16); crypto.getRandomValues(salt);
    var sb = toB64(salt.buffer);
    return hashPin(pin, sb, 100000).then(function (h) {
      store.set('lock', JSON.stringify({ salt: sb, hash: h, iter: 100000, len: pin.length, timeout: timeout }));
    });
  }
  function checkPin(pin) {
    var c = lockCfg();
    if (!c) return Promise.resolve(true);
    return hashPin(pin, c.salt, c.iter).then(function (h) { return h === c.hash; });
  }
  function drawDots() {
    var c = lockCfg(), n = c ? c.len : 4, h = '';
    for (var i = 0; i < n; i++) h += '<i class="' + (i < pinBuf.length ? 'on' : '') + '"></i>';
    el('lock-dots').innerHTML = h;
  }
  function buildKeys() {
    var keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del'];
    el('lock-keys').innerHTML = keys.map(function (k) {
      if (!k) return '<span></span>';
      return '<button class="key" data-action="lock-key" data-value="' + k + '" aria-label="' + (k === 'del' ? 'Delete' : k) + '">' + (k === 'del' ? '&#9003;' : k) + '</button>';
    }).join('');
  }
  function showLock() {
    if (!lockCfg()) return;
    locked = true; pinBuf = '';
    el('lock-reset').hidden = true;
    el('lock-msg').textContent = 'Enter your PIN';
    drawDots();
    el('lock').classList.add('on');
    el('lock').setAttribute('aria-hidden', 'false');
    var cfg = lockCfg();
    el('lock-bio').hidden = !(cfg && cfg.bio);
    if (cfg && cfg.bio) setTimeout(tryBio, 350);
  }
  function unlock() {
    locked = false; pinBuf = ''; failCount = 0;
    el('lock').classList.remove('on');
    el('lock').setAttribute('aria-hidden', 'true');
  }
  function lockKey(k) {
    if (Date.now() < lockedUntil) { el('lock-msg').textContent = 'Too many tries. Wait ' + Math.ceil((lockedUntil - Date.now()) / 1000) + ' seconds'; return; }
    var c = lockCfg();
    if (!c) { unlock(); return; }
    if (k === 'del') pinBuf = pinBuf.slice(0, -1); else if (pinBuf.length < c.len) pinBuf += k;
    drawDots();
    if (pinBuf.length === c.len) {
      var attempt = pinBuf;
      checkPin(attempt).then(function (ok) {
        if (ok) { unlock(); return; }
        failCount++; pinBuf = ''; drawDots();
        if (failCount >= 5) { lockedUntil = Date.now() + 30000; failCount = 0; el('lock-msg').textContent = 'Too many tries. Wait 30 seconds'; }
        else el('lock-msg').textContent = 'Wrong PIN. Try again';
      });
    }
  }
  function lockReset() {
    var pw = el('lock-pass').value;
    if (!pw) { el('lock-reset-note').textContent = 'Type your account password.'; return; }
    NexoraSync.verify(pw).then(function () {
      store.set('lock', ''); el('lock-pass').value = ''; unlock();
      toast('PIN removed. Set a new one in Settings.');
    }).catch(function (e) { el('lock-reset-note').textContent = e.message; });
  }
  document.addEventListener('visibilitychange', function () {
    var c = lockCfg();
    if (document.hidden) { hiddenAt = Date.now(); return; }
    if (c && !locked && hiddenAt && (Date.now() - hiddenAt) / 1000 >= c.timeout) showLock();
  });

  function viewSecurity() {
    var c = lockCfg();
    var back = '<button class="back" data-action="back">' + ic('back') + 'Settings</button><div class="title-row"><h1 class="page">Security</h1></div>';
    if (!c) {
      return back + '<p class="note-hint">Protect NEXORA with a PIN. It is asked when you open the app and after you leave it.</p>' +
        '<div class="actions"><button class="btn" data-action="pin-set">Set a PIN</button></div>';
    }
    var opts = TIMEOUTS.map(function (t) { return '<option value="' + t[0] + '"' + (t[0] === c.timeout ? ' selected' : '') + '>' + t[1] + '</option>'; }).join('');
    return back + '<div class="group"><div class="row"><span class="row-ic">' + ic('lock') + '</span><span class="row-label">App lock is on</span></div></div>' +
      (bioOk ? '<div class="group"><div class="row"><span class="row-ic">' + ic('lock') + '</span><span class="row-label">Unlock with fingerprint</span><button class="switch" data-action="bio-toggle" aria-label="Fingerprint unlock" aria-pressed="' + (!!c.bio) + '"></button></div></div>' : '') +
      '<label class="field"><span>Ask for the PIN</span><select id="lock-timeout" data-change="lock-timeout">' + opts + '</select></label>' +
      '<div class="group">' + row('edit', 'Change PIN', '', 'pin-change', '') + row('trash', 'Remove PIN', '', 'pin-remove', '') + '</div>' +
      '<p class="note-hint">Forgot your PIN? On the lock screen tap "Forgot PIN?" and type your NEXORA account password.</p>';
  }
  function openPinForm(mode) {
    var c = lockCfg();
    var needCurrent = mode !== 'set', needNew = mode !== 'remove';
    openModal('<h2>' + (mode === 'set' ? 'Set a PIN' : mode === 'change' ? 'Change PIN' : 'Remove PIN') + '</h2>' +
      (mode === 'set' && !NexoraSync.signedIn() ? '<p class="note-hint">Tip: sign in to your account first (Settings, Account and backup). Then you can reset a forgotten PIN with your account password.</p>' : '') +
      (needCurrent ? '<label class="field"><span>Current PIN</span><input id="p-cur" type="password" inputmode="numeric" maxlength="6" autocomplete="off"></label>' : '') +
      (needNew ? '<label class="field"><span>New PIN (4 to 6 digits)</span><input id="p-new" type="password" inputmode="numeric" maxlength="6" autocomplete="off"></label>' +
        '<label class="field"><span>Repeat new PIN</span><input id="p-new2" type="password" inputmode="numeric" maxlength="6" autocomplete="off"></label>' : '') +
      '<div class="actions"><button class="btn ghost" data-action="close-sheet">Cancel</button><button class="btn" data-action="pin-save" data-value="' + mode + '">' + (mode === 'remove' ? 'Remove' : 'Save') + '</button></div>');
    void c;
  }
  function savePinForm(mode) {
    var cur = el('p-cur') ? el('p-cur').value : '', n1 = el('p-new') ? el('p-new').value : '', n2 = el('p-new2') ? el('p-new2').value : '';
    var c = lockCfg();
    function go() {
      if (mode === 'remove') { store.set('lock', ''); closeModal(); render(); toast('PIN removed'); return; }
      if (!/^\d{4,6}$/.test(n1)) { toast('The PIN must be 4 to 6 digits'); return; }
      if (n1 !== n2) { toast('The two PINs do not match'); return; }
      savePin(n1, c ? c.timeout : 30).then(function () { closeModal(); render(); toast(mode === 'set' ? 'PIN is on' : 'PIN changed'); });
    }
    if (mode === 'set') { go(); return; }
    checkPin(cur).then(function (ok) { if (!ok) { toast('Current PIN is wrong'); return; } go(); });
  }

  /* ---------- Android back button: go back one step, never exit by accident ---------- */
  var exitArmed = false, exitTimer;
  function capApp() {
    try { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App; } catch (e) { return null; }
  }
  function onBack() {
    if (locked) { var LA = capApp(); if (LA && LA.exitApp) LA.exitApp(); return; }
    if (el('modal').classList.contains('on') || el('sheet').classList.contains('on')) { closeAll(); return; }
    var r = route(), tab = r[0];
    if (tab !== 'home') {
      if ((tab === 'platforms' || tab === 'saved' || tab === 'settings') && !r[1]) { location.replace('#/home'); return; }
      if (history.length > 1) history.back(); else location.replace('#/home');
      return;
    }
    if (exitArmed) { var A = capApp(); if (A && A.exitApp) A.exitApp(); return; }
    exitArmed = true;
    toast('Press back again to exit');
    clearTimeout(exitTimer);
    exitTimer = setTimeout(function () { exitArmed = false; }, 2000);
  }
  function setupBack() {
    var A = capApp();
    if (A && A.addListener) A.addListener('backButton', onBack);
  }
  window.nexoraBack = onBack;

  /* ---------- start ---------- */
  function seedPlatforms() {
    SEED_PLATFORMS.forEach(function (p, i) {
      if (!DB.get('platforms', p.id)) {
        DB.put('platforms', { id: p.id, name: p.name, color: p.color, domains: p.domains, builtin: true, createdAt: 1000 + i, updatedAt: 1000 + i }, true);
      }
    });
  }
  function init() {
    var holders = document.querySelectorAll('[data-icon]');
    for (var i = 0; i < holders.length; i++) holders[i].innerHTML = ic(holders[i].getAttribute('data-icon'));
    buildSheet();
    bioAvailable().then(function (v) { bioOk = v; if (route().join('/') === 'settings/security') render(); });
    buildKeys();
    showLock();
    setupBack();
    DB.open().then(function () {
      seedPlatforms();
      purgeOld();
      render();
      checkShare();
      NexoraSync.start({
        onRemote: function () { rerenderSoon(); },
        onStatus: function () { if (route().join('/') === 'settings/account') render(); }
      });
      if (!DB.persistent()) toast('Storage is not available. Changes will not be kept.');
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
